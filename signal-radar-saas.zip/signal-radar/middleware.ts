import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/server';

export default withAuth(
  function middleware(req) {
    // Add custom middleware logic here if needed
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token, req }) => {
        const { pathname } = req.nextUrl;
        
        // Public routes - no auth required
        const publicRoutes = ['/', '/login', '/signup', '/pricing', '/api/webhooks'];
        
        if (publicRoutes.some(route => pathname.startsWith(route))) {
          return true;
        }
        
        // API routes that don't need auth
        if (pathname.startsWith('/api/checkout') && req.method === 'GET') {
          return true;
        }
        
        // All other routes require auth
        return !!token;
      },
    },
    pages: {
      signIn: '/login',
    },
  }
);

export const config = {
  matcher: [
    // Match all routes except static files and images
    '/((?!_next/static|_next/image|favicon.ico|.*\\..*|api/webhooks).*)',
  ],
};
