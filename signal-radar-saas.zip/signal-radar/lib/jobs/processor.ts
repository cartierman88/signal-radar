import { Queue, Worker, Job } from 'bullmq';
import IORedis from 'ioredis';
import prisma from '@/lib/db';
import { 
  getDiscordClient,
  getTwitterClient,
  getTelegramClient,
  DiscordMessage,
  Tweet,
  TelegramMessage,
} from '@/lib/integrations';
import { extractKeywords, analyzeSentiment } from '@/lib/integrations/openai';

// Redis connection for job queue
const connection = new IORedis(process.env.REDIS_URL || 'redis://localhost:6379', {
  maxRetriesPerRequest: null,
});

// Job types
interface ProcessMessageJob {
  type: 'discord' | 'twitter' | 'telegram';
  sourceId: string;
  message: DiscordMessage | Tweet | TelegramMessage;
}

interface CalculateSignalsJob {
  userId: string;
  timeWindow: number; // minutes
}

interface SendAlertJob {
  userId: string;
  signalId: string;
  alertRuleId: string;
}

// Create queues
export const messageQueue = new Queue<ProcessMessageJob>('message-processing', { connection });
export const signalQueue = new Queue<CalculateSignalsJob>('signal-calculation', { connection });
export const alertQueue = new Queue<SendAlertJob>('alert-sending', { connection });

// Message processing worker
export const messageWorker = new Worker<ProcessMessageJob>(
  'message-processing',
  async (job: Job<ProcessMessageJob>) => {
    const { type, sourceId, message } = job.data;
    
    console.log(`[Worker] Processing ${type} message from source ${sourceId}`);

    try {
      // Extract text content based on message type
      let text: string;
      let externalId: string;
      let authorId: string;
      let authorName: string;
      let authorFollowers: number | undefined;

      if (type === 'discord') {
        const msg = message as DiscordMessage;
        text = msg.content;
        externalId = msg.id;
        authorId = msg.authorId;
        authorName = msg.authorName;
      } else if (type === 'twitter') {
        const msg = message as Tweet;
        text = msg.text;
        externalId = msg.id;
        authorId = msg.authorId;
        authorName = msg.authorUsername;
        authorFollowers = msg.authorFollowers;
      } else {
        const msg = message as TelegramMessage;
        text = msg.text;
        externalId = msg.id.toString();
        authorId = msg.authorId.toString();
        authorName = msg.authorUsername || msg.authorFirstName;
      }

      // Skip if too short
      if (text.length < 10) {
        return { skipped: true, reason: 'too_short' };
      }

      // Extract keywords
      const keywords = await extractKeywords(text);
      
      if (keywords.length === 0) {
        return { skipped: true, reason: 'no_keywords' };
      }

      // Analyze sentiment
      const sentimentResult = await analyzeSentiment([text]);

      // Save message to database
      await prisma.message.create({
        data: {
          sourceId,
          externalId,
          content: text,
          authorId,
          authorName,
          authorFollowers,
          keywords,
          sentiment: sentimentResult.overall,
          processedAt: new Date(),
        },
      });

      // Update source message count
      await prisma.source.update({
        where: { id: sourceId },
        data: {
          messageCount: { increment: 1 },
          lastSync: new Date(),
        },
      });

      return { 
        success: true, 
        keywords,
        sentiment: sentimentResult.overall,
      };
    } catch (error) {
      console.error('[Worker] Message processing error:', error);
      throw error;
    }
  },
  { connection, concurrency: 10 }
);

// Signal calculation worker
export const signalWorker = new Worker<CalculateSignalsJob>(
  'signal-calculation',
  async (job: Job<CalculateSignalsJob>) => {
    const { userId, timeWindow } = job.data;
    
    console.log(`[Worker] Calculating signals for user ${userId}`);

    try {
      const since = new Date(Date.now() - timeWindow * 60 * 1000);

      // Get all messages in time window
      const messages = await prisma.message.findMany({
        where: {
          source: { userId },
          createdAt: { gte: since },
        },
        select: {
          keywords: true,
          sentiment: true,
          authorFollowers: true,
          sourceId: true,
        },
      });

      // Aggregate keywords
      const keywordStats: Record<string, {
        mentions: number;
        sentiment: number;
        influencerSeeds: number;
        sources: Set<string>;
      }> = {};

      for (const msg of messages) {
        for (const keyword of msg.keywords) {
          if (!keywordStats[keyword]) {
            keywordStats[keyword] = {
              mentions: 0,
              sentiment: 0,
              influencerSeeds: 0,
              sources: new Set(),
            };
          }
          
          keywordStats[keyword].mentions++;
          keywordStats[keyword].sentiment += msg.sentiment || 0.5;
          keywordStats[keyword].sources.add(msg.sourceId);
          
          // Count as influencer seed if author has > 10k followers
          if (msg.authorFollowers && msg.authorFollowers > 10000) {
            keywordStats[keyword].influencerSeeds++;
          }
        }
      }

      // Update signals
      for (const [keyword, stats] of Object.entries(keywordStats)) {
        const existing = await prisma.signal.findUnique({
          where: { userId_keyword: { userId, keyword } },
        });

        const prevMentions = existing?.mentions || 0;
        const change24h = prevMentions > 0 
          ? ((stats.mentions - prevMentions) / prevMentions) * 100 
          : 100;

        // Determine status
        let status: 'NEW' | 'EMERGING' | 'RISING' | 'HOT' = 'NEW';
        if (change24h > 200) status = 'HOT';
        else if (change24h > 100) status = 'RISING';
        else if (change24h > 50) status = 'EMERGING';

        const avgSentiment = stats.sentiment / stats.mentions;

        // Get trend data
        const existingTrend = (existing?.trendData as number[]) || [];
        const newTrend = [...existingTrend.slice(-23), stats.mentions];

        await prisma.signal.upsert({
          where: { userId_keyword: { userId, keyword } },
          create: {
            userId,
            keyword,
            mentions: stats.mentions,
            mentionsPrev24h: 0,
            change24h,
            sentiment: avgSentiment,
            influencerSeeds: stats.influencerSeeds,
            status,
            trendData: newTrend,
          },
          update: {
            mentions: stats.mentions,
            mentionsPrev24h: prevMentions,
            change24h,
            sentiment: avgSentiment,
            influencerSeeds: stats.influencerSeeds,
            status,
            trendData: newTrend,
            lastSeen: new Date(),
          },
        });

        // Check alert rules if signal crossed threshold
        if (status === 'HOT' || status === 'RISING') {
          const alertRules = await prisma.alertRule.findMany({
            where: {
              userId,
              isActive: true,
              type: 'KEYWORD_SPIKE',
              threshold: { lte: change24h },
            },
          });

          for (const rule of alertRules) {
            const signal = await prisma.signal.findUnique({
              where: { userId_keyword: { userId, keyword } },
            });

            if (signal) {
              await alertQueue.add('send-alert', {
                userId,
                signalId: signal.id,
                alertRuleId: rule.id,
              });
            }
          }
        }
      }

      return { 
        success: true, 
        keywordsProcessed: Object.keys(keywordStats).length,
      };
    } catch (error) {
      console.error('[Worker] Signal calculation error:', error);
      throw error;
    }
  },
  { connection, concurrency: 5 }
);

// Alert sending worker
export const alertWorker = new Worker<SendAlertJob>(
  'alert-sending',
  async (job: Job<SendAlertJob>) => {
    const { userId, signalId, alertRuleId } = job.data;
    
    console.log(`[Worker] Sending alert for signal ${signalId}`);

    try {
      const [signal, alertRule, user] = await Promise.all([
        prisma.signal.findUnique({ where: { id: signalId } }),
        prisma.alertRule.findUnique({ where: { id: alertRuleId } }),
        prisma.user.findUnique({ where: { id: userId } }),
      ]);

      if (!signal || !alertRule || !user) {
        return { skipped: true, reason: 'not_found' };
      }

      const channels = alertRule.channels;

      // Send to each configured channel
      for (const channel of channels) {
        switch (channel) {
          case 'telegram': {
            const telegram = getTelegramClient();
            // Assume we have a telegram chat ID stored somewhere
            // await telegram.sendAlert(chatId, signal);
            break;
          }
          
          case 'email': {
            // TODO: Implement email sending
            // await sendEmail(user.email, { signal });
            break;
          }
          
          case 'discord': {
            // TODO: Implement Discord DM
            break;
          }
          
          case 'slack': {
            if (alertRule.webhookUrl) {
              await fetch(alertRule.webhookUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  text: `🚨 Signal Alert: ${signal.keyword}`,
                  blocks: [
                    {
                      type: 'section',
                      text: {
                        type: 'mrkdwn',
                        text: `*${signal.keyword}* is ${signal.status}\n📊 +${signal.change24h.toFixed(0)}% in 24h\n💬 ${signal.mentions.toLocaleString()} mentions`,
                      },
                    },
                  ],
                }),
              });
            }
            break;
          }
        }
      }

      // Update alert rule
      await prisma.alertRule.update({
        where: { id: alertRuleId },
        data: {
          lastTriggered: new Date(),
          triggerCount: { increment: 1 },
        },
      });

      return { success: true, channels };
    } catch (error) {
      console.error('[Worker] Alert sending error:', error);
      throw error;
    }
  },
  { connection, concurrency: 20 }
);

// Start source monitoring
export async function startSourceMonitoring(userId: string) {
  const sources = await prisma.source.findMany({
    where: { userId, isActive: true },
  });

  const discord = getDiscordClient();
  const twitter = getTwitterClient();
  const telegram = getTelegramClient();

  for (const source of sources) {
    switch (source.type) {
      case 'DISCORD':
        discord.subscribeToChannel(source.channelId, async (message) => {
          await messageQueue.add('process-message', {
            type: 'discord',
            sourceId: source.id,
            message,
          });
        });
        break;

      case 'TWITTER':
        twitter.subscribeToStream(async (tweet) => {
          await messageQueue.add('process-message', {
            type: 'twitter',
            sourceId: source.id,
            message: tweet,
          });
        });
        break;

      case 'TELEGRAM':
        telegram.subscribeToChat(parseInt(source.channelId), async (message) => {
          await messageQueue.add('process-message', {
            type: 'telegram',
            sourceId: source.id,
            message,
          });
        });
        break;
    }
  }

  console.log(`[Monitoring] Started for ${sources.length} sources`);
}

// Schedule regular signal calculations
export async function scheduleSignalCalculations() {
  const users = await prisma.user.findMany({
    where: {
      sources: { some: { isActive: true } },
    },
    select: { id: true },
  });

  for (const user of users) {
    await signalQueue.add(
      'calculate-signals',
      { userId: user.id, timeWindow: 60 },
      { repeat: { every: 5 * 60 * 1000 } } // Every 5 minutes
    );
  }

  console.log(`[Scheduler] Scheduled calculations for ${users.length} users`);
}

// Graceful shutdown
export async function shutdownWorkers() {
  await messageWorker.close();
  await signalWorker.close();
  await alertWorker.close();
  await connection.quit();
}

export {
  messageQueue,
  signalQueue,
  alertQueue,
};
