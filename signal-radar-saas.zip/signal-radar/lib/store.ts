import { create } from 'zustand';
import { Signal, Source, AlertRule, ContentBrief, DashboardStats } from '@/types';

interface SignalRadarStore {
  // State
  signals: Signal[];
  sources: Source[];
  alerts: AlertRule[];
  briefs: ContentBrief[];
  isScanning: boolean;
  lastSyncTime: Date | null;
  stats: DashboardStats;
  selectedSignal: Signal | null;
  
  // Actions
  setSignals: (signals: Signal[]) => void;
  addSignal: (signal: Signal) => void;
  updateSignal: (id: string, updates: Partial<Signal>) => void;
  
  setSources: (sources: Source[]) => void;
  addSource: (source: Source) => void;
  toggleSource: (id: string) => void;
  removeSource: (id: string) => void;
  
  setAlerts: (alerts: AlertRule[]) => void;
  addAlert: (alert: AlertRule) => void;
  toggleAlert: (id: string) => void;
  
  addBrief: (brief: ContentBrief) => void;
  updateBrief: (id: string, updates: Partial<ContentBrief>) => void;
  
  setIsScanning: (isScanning: boolean) => void;
  setLastSyncTime: (time: Date) => void;
  updateStats: (stats: Partial<DashboardStats>) => void;
  
  selectSignal: (signal: Signal | null) => void;
}

// Mock initial data for demo
const mockSignals: Signal[] = [
  {
    id: '1',
    keyword: '$VIRTUAL agents',
    status: 'hot',
    mentions: 2847,
    change24h: 340,
    sentiment: 78,
    sources: [],
    firstSeen: new Date(Date.now() - 48 * 60 * 60 * 1000),
    lastSeen: new Date(),
    samplePosts: [],
    influencerSeeds: 12,
    trendData: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() - (23 - i) * 60 * 60 * 1000),
      mentions: Math.floor(50 + Math.random() * 150 + i * 10),
      sentiment: 65 + Math.random() * 20
    }))
  },
  {
    id: '2',
    keyword: 'Base chain migration',
    status: 'rising',
    mentions: 1203,
    change24h: 127,
    sentiment: 72,
    sources: [],
    firstSeen: new Date(Date.now() - 72 * 60 * 60 * 1000),
    lastSeen: new Date(),
    samplePosts: [],
    influencerSeeds: 7,
    trendData: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() - (23 - i) * 60 * 60 * 1000),
      mentions: Math.floor(30 + Math.random() * 80 + i * 5),
      sentiment: 60 + Math.random() * 25
    }))
  },
  {
    id: '3',
    keyword: 'MCP protocol',
    status: 'emerging',
    mentions: 487,
    change24h: 78,
    sentiment: 82,
    sources: [],
    firstSeen: new Date(Date.now() - 24 * 60 * 60 * 1000),
    lastSeen: new Date(),
    samplePosts: [],
    influencerSeeds: 3,
    trendData: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() - (23 - i) * 60 * 60 * 1000),
      mentions: Math.floor(10 + Math.random() * 30 + i * 3),
      sentiment: 75 + Math.random() * 15
    }))
  },
  {
    id: '4',
    keyword: 'Solana restaking',
    status: 'rising',
    mentions: 892,
    change24h: 95,
    sentiment: 69,
    sources: [],
    firstSeen: new Date(Date.now() - 36 * 60 * 60 * 1000),
    lastSeen: new Date(),
    samplePosts: [],
    influencerSeeds: 5,
    trendData: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() - (23 - i) * 60 * 60 * 1000),
      mentions: Math.floor(25 + Math.random() * 60 + i * 4),
      sentiment: 55 + Math.random() * 30
    }))
  },
  {
    id: '5',
    keyword: 'AI agents trading',
    status: 'emerging',
    mentions: 324,
    change24h: 56,
    sentiment: 74,
    sources: [],
    firstSeen: new Date(Date.now() - 12 * 60 * 60 * 1000),
    lastSeen: new Date(),
    samplePosts: [],
    influencerSeeds: 2,
    trendData: Array.from({ length: 24 }, (_, i) => ({
      timestamp: new Date(Date.now() - (23 - i) * 60 * 60 * 1000),
      mentions: Math.floor(5 + Math.random() * 20 + i * 2),
      sentiment: 70 + Math.random() * 20
    }))
  }
];

const mockSources: Source[] = [
  {
    id: '1',
    type: 'discord',
    name: 'DeFi Alpha',
    channelId: '123456',
    isActive: true,
    lastSync: new Date(),
    messageCount: 45230
  },
  {
    id: '2',
    type: 'twitter',
    name: 'Crypto Twitter Lists',
    isActive: true,
    lastSync: new Date(),
    messageCount: 128450
  },
  {
    id: '3',
    type: 'telegram',
    name: 'Solana Trading',
    channelId: 'soltrading',
    isActive: true,
    lastSync: new Date(),
    messageCount: 67890
  },
  {
    id: '4',
    type: 'discord',
    name: 'Base Builders',
    channelId: '789012',
    isActive: false,
    lastSync: new Date(Date.now() - 24 * 60 * 60 * 1000),
    messageCount: 23100
  }
];

const mockAlerts: AlertRule[] = [
  {
    id: '1',
    name: 'Keyword Spike Alert',
    type: 'keyword_spike',
    threshold: 100,
    timeWindow: 24,
    channels: ['slack', 'email'],
    isActive: true
  },
  {
    id: '2',
    name: 'Influencer Seed Detection',
    type: 'influencer_seed',
    threshold: 3,
    timeWindow: 12,
    channels: ['slack'],
    isActive: true
  },
  {
    id: '3',
    name: 'Sentiment Shift',
    type: 'sentiment_shift',
    threshold: 20,
    timeWindow: 6,
    channels: ['email'],
    isActive: false
  }
];

export const useSignalRadarStore = create<SignalRadarStore>((set, get) => ({
  // Initial state
  signals: mockSignals,
  sources: mockSources,
  alerts: mockAlerts,
  briefs: [],
  isScanning: true,
  lastSyncTime: new Date(),
  stats: {
    activeSignals: 127,
    hotTrends: 12,
    messagesAnalyzed: 847000,
    briefsGenerated: 34,
    sourcesActive: 47
  },
  selectedSignal: null,

  // Signal actions
  setSignals: (signals) => set({ signals }),
  addSignal: (signal) => set((state) => ({ 
    signals: [signal, ...state.signals] 
  })),
  updateSignal: (id, updates) => set((state) => ({
    signals: state.signals.map((s) => 
      s.id === id ? { ...s, ...updates } : s
    )
  })),

  // Source actions
  setSources: (sources) => set({ sources }),
  addSource: (source) => set((state) => ({ 
    sources: [...state.sources, source] 
  })),
  toggleSource: (id) => set((state) => ({
    sources: state.sources.map((s) =>
      s.id === id ? { ...s, isActive: !s.isActive } : s
    )
  })),
  removeSource: (id) => set((state) => ({
    sources: state.sources.filter((s) => s.id !== id)
  })),

  // Alert actions
  setAlerts: (alerts) => set({ alerts }),
  addAlert: (alert) => set((state) => ({
    alerts: [...state.alerts, alert]
  })),
  toggleAlert: (id) => set((state) => ({
    alerts: state.alerts.map((a) =>
      a.id === id ? { ...a, isActive: !a.isActive } : a
    )
  })),

  // Brief actions
  addBrief: (brief) => set((state) => ({
    briefs: [brief, ...state.briefs],
    stats: { ...state.stats, briefsGenerated: state.stats.briefsGenerated + 1 }
  })),
  updateBrief: (id, updates) => set((state) => ({
    briefs: state.briefs.map((b) =>
      b.id === id ? { ...b, ...updates } : b
    )
  })),

  // Utility actions
  setIsScanning: (isScanning) => set({ isScanning }),
  setLastSyncTime: (time) => set({ lastSyncTime: time }),
  updateStats: (stats) => set((state) => ({
    stats: { ...state.stats, ...stats }
  })),
  selectSignal: (signal) => set({ selectedSignal: signal })
}));
