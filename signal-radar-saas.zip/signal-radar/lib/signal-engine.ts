import { Signal, RawMessage, TrendDataPoint } from '@/types';

// Keyword extraction and analysis
export function extractKeywords(messages: RawMessage[]): Map<string, number> {
  const keywords = new Map<string, number>();
  
  // Common crypto/AI terms to track
  const trackedPatterns = [
    /\$[A-Z]{2,10}/g,  // Token tickers
    /\b(airdrop|launch|migration|restaking|staking|yield|APY|TVL)\b/gi,
    /\b(AI agent|autonomous|MCP|protocol|layer\s*2|L2|rollup)\b/gi,
    /\b(pump|dump|moon|rug|alpha|degen|ape)\b/gi,
    /\b(Solana|Base|Ethereum|Arbitrum|Optimism)\b/gi
  ];

  for (const msg of messages) {
    const content = msg.content.toLowerCase();
    
    for (const pattern of trackedPatterns) {
      const matches = content.match(pattern) || [];
      for (const match of matches) {
        const normalized = match.toLowerCase().trim();
        keywords.set(normalized, (keywords.get(normalized) || 0) + 1);
      }
    }
  }

  return keywords;
}

// Calculate keyword spike
export function calculateSpike(
  currentCount: number,
  historicalAvg: number
): number {
  if (historicalAvg === 0) return currentCount > 0 ? 100 : 0;
  return Math.round(((currentCount - historicalAvg) / historicalAvg) * 100);
}

// Classify signal status based on spike percentage
export function classifySignalStatus(
  spikePercentage: number
): Signal['status'] {
  if (spikePercentage >= 200) return 'hot';
  if (spikePercentage >= 100) return 'rising';
  if (spikePercentage >= 50) return 'emerging';
  return 'new';
}

// Simple sentiment analysis (replace with actual NLP in production)
export function analyzeSentiment(text: string): number {
  const positiveWords = [
    'bullish', 'moon', 'pump', 'alpha', 'gem', 'buy', 'long',
    'amazing', 'incredible', 'revolutionary', 'huge', 'massive',
    'opportunity', 'undervalued', 'early'
  ];
  
  const negativeWords = [
    'bearish', 'dump', 'rug', 'scam', 'sell', 'short', 'avoid',
    'terrible', 'dead', 'overvalued', 'late', 'exit', 'warning'
  ];

  const lowerText = text.toLowerCase();
  let score = 50; // Neutral baseline

  for (const word of positiveWords) {
    if (lowerText.includes(word)) score += 5;
  }
  
  for (const word of negativeWords) {
    if (lowerText.includes(word)) score -= 5;
  }

  return Math.max(0, Math.min(100, score));
}

// Detect influencer posts (simplified - use follower count in production)
export function isInfluencerPost(
  engagement: number,
  avgEngagement: number
): boolean {
  return engagement > avgEngagement * 5;
}

// Generate trend data from messages
export function generateTrendData(
  messages: RawMessage[],
  keyword: string,
  hours: number = 24
): TrendDataPoint[] {
  const now = new Date();
  const dataPoints: TrendDataPoint[] = [];
  
  for (let i = hours - 1; i >= 0; i--) {
    const hourStart = new Date(now.getTime() - (i + 1) * 60 * 60 * 1000);
    const hourEnd = new Date(now.getTime() - i * 60 * 60 * 1000);
    
    const hourMessages = messages.filter(msg => {
      const msgTime = new Date(msg.timestamp);
      return msgTime >= hourStart && 
             msgTime < hourEnd && 
             msg.content.toLowerCase().includes(keyword.toLowerCase());
    });

    const avgSentiment = hourMessages.length > 0
      ? hourMessages.reduce((acc, m) => acc + analyzeSentiment(m.content), 0) / hourMessages.length
      : 50;

    dataPoints.push({
      timestamp: hourEnd,
      mentions: hourMessages.length,
      sentiment: Math.round(avgSentiment)
    });
  }

  return dataPoints;
}

// Detect recurring questions
export function detectRecurringQuestions(messages: RawMessage[]): string[] {
  const questionPatterns = messages
    .filter(m => m.content.includes('?'))
    .map(m => m.content.toLowerCase());

  const questionCounts = new Map<string, number>();
  
  for (const q of questionPatterns) {
    // Normalize question
    const normalized = q
      .replace(/[^\w\s?]/g, '')
      .split(' ')
      .filter(w => w.length > 3)
      .slice(0, 5)
      .join(' ');
    
    if (normalized.length > 10) {
      questionCounts.set(normalized, (questionCounts.get(normalized) || 0) + 1);
    }
  }

  return Array.from(questionCounts.entries())
    .filter(([_, count]) => count >= 3)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([q]) => q);
}

// Process batch of messages and return signals
export function processMessages(messages: RawMessage[]): Partial<Signal>[] {
  const keywords = extractKeywords(messages);
  const signals: Partial<Signal>[] = [];

  keywords.forEach((count, keyword) => {
    if (count >= 10) { // Minimum threshold
      const relevantMessages = messages.filter(m => 
        m.content.toLowerCase().includes(keyword.toLowerCase())
      );
      
      const avgSentiment = relevantMessages.reduce(
        (acc, m) => acc + analyzeSentiment(m.content), 0
      ) / relevantMessages.length;

      const influencerCount = relevantMessages.filter(m => 
        isInfluencerPost(m.engagement || 0, 100)
      ).length;

      // Calculate spike (mock historical avg for demo)
      const historicalAvg = count * 0.3; // Assume 30% was historical
      const spike = calculateSpike(count, historicalAvg);

      signals.push({
        keyword,
        mentions: count,
        change24h: spike,
        status: classifySignalStatus(spike),
        sentiment: Math.round(avgSentiment),
        influencerSeeds: influencerCount,
        trendData: generateTrendData(messages, keyword)
      });
    }
  });

  return signals.sort((a, b) => (b.change24h || 0) - (a.change24h || 0));
}
