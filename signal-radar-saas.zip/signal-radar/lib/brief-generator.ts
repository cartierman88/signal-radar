import { Signal, ContentBrief, Platform } from '@/types';

// Brief generation prompt templates
const BRIEF_SYSTEM_PROMPT = `You are an expert crypto/AI content strategist. Generate viral content briefs that capture emerging narratives early. 

Your briefs should:
- Hook readers in the first line with urgency or curiosity
- Provide specific data points and percentages
- Include contrarian or insider angles
- Suggest hashtags that trend in crypto/AI communities
- Adapt tone for different platforms`;

export function generateBriefPrompt(
  signal: Signal,
  tone: 'professional' | 'casual' | 'urgent' | 'educational' = 'casual'
): string {
  return `Generate a content brief for this emerging signal:

SIGNAL DATA:
- Keyword: "${signal.keyword}"
- Mention spike: +${signal.change24h}% in 24h
- Total mentions: ${signal.mentions}
- Sentiment: ${signal.sentiment}% bullish
- Influencer seeds: ${signal.influencerSeeds} detected
- First seen: ${getTimeAgo(signal.firstSeen)}

TONE: ${tone}

Generate:
1. HOOK: One attention-grabbing opening line (max 15 words)
2. KEY_ANGLES: 3 unique angles to cover this topic
3. DATA_POINTS: 3 specific stats or facts to include
4. HASHTAGS: 5 relevant hashtags
5. TWITTER_THREAD: 3-tweet thread outline
6. NEWSLETTER_ANGLE: One paragraph hook for email

Format as JSON.`;
}

// Parse AI response into ContentBrief
export function parseBriefResponse(
  response: string,
  signal: Signal
): ContentBrief {
  try {
    // Try to extract JSON from response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    const parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : null;

    if (parsed) {
      return {
        id: generateId(),
        signalId: signal.id,
        keyword: signal.keyword,
        generatedAt: new Date(),
        hook: parsed.HOOK || parsed.hook || '',
        keyAngles: parsed.KEY_ANGLES || parsed.key_angles || [],
        dataPoints: (parsed.DATA_POINTS || parsed.data_points || []).map((d: string) => ({
          label: d,
          value: d
        })),
        suggestedHashtags: parsed.HASHTAGS || parsed.hashtags || [],
        toneGuidance: 'Match the energy of crypto twitter - confident, data-driven, slightly contrarian',
        platforms: [
          {
            name: 'twitter',
            adaptedContent: parsed.TWITTER_THREAD || '',
            characterCount: (parsed.TWITTER_THREAD || '').length
          },
          {
            name: 'newsletter',
            adaptedContent: parsed.NEWSLETTER_ANGLE || '',
            characterCount: (parsed.NEWSLETTER_ANGLE || '').length
          }
        ],
        status: 'draft'
      };
    }
  } catch (e) {
    console.error('Failed to parse brief response:', e);
  }

  // Fallback to template-based brief
  return generateTemplateBrief(signal);
}

// Template-based fallback brief generation
export function generateTemplateBrief(signal: Signal): ContentBrief {
  const hooks = [
    `Everyone's sleeping on ${signal.keyword} while the smart money accumulates...`,
    `${signal.keyword} just hit +${signal.change24h}% mentions. Here's what CT is missing...`,
    `I've been tracking ${signal.keyword} for 48 hours. The signal is undeniable.`,
    `The ${signal.keyword} narrative is about to explode. Here's why...`,
    `${signal.influencerSeeds} alpha accounts are seeding ${signal.keyword}. Coincidence?`
  ];

  const angles = [
    `Technical fundamentals driving the narrative`,
    `Key players and influencers pushing this`,
    `Historical pattern comparison`,
    `Risk factors and counter-arguments`,
    `Actionable opportunities for readers`
  ];

  const hashtags = [
    `#${signal.keyword.replace(/[^a-zA-Z0-9]/g, '')}`,
    '#CryptoAlpha',
    '#DeFi',
    '#Web3',
    '#CryptoTwitter'
  ];

  return {
    id: generateId(),
    signalId: signal.id,
    keyword: signal.keyword,
    generatedAt: new Date(),
    hook: hooks[Math.floor(Math.random() * hooks.length)],
    keyAngles: angles.slice(0, 3),
    dataPoints: [
      { label: 'Mention spike', value: `+${signal.change24h}% in 24h` },
      { label: 'Total mentions', value: `${signal.mentions.toLocaleString()}` },
      { label: 'Sentiment', value: `${signal.sentiment}% bullish` },
      { label: 'Influencer seeds', value: `${signal.influencerSeeds} detected` }
    ],
    suggestedHashtags: hashtags,
    toneGuidance: 'Confident but not cocky. Data-driven with narrative flair.',
    platforms: [
      {
        name: 'twitter',
        adaptedContent: `🧵 Thread: ${signal.keyword} is spiking +${signal.change24h}%\n\nHere's what you need to know...`,
        characterCount: 280
      },
      {
        name: 'newsletter',
        adaptedContent: `This week's alpha drop: ${signal.keyword}\n\nThe data is clear - something is brewing...`,
        characterCount: 500
      }
    ],
    status: 'draft'
  };
}

// Adapt brief for specific platform
export function adaptForPlatform(
  brief: ContentBrief,
  platform: 'twitter' | 'linkedin' | 'newsletter' | 'discord'
): string {
  const { hook, keyAngles, dataPoints, suggestedHashtags } = brief;

  switch (platform) {
    case 'twitter':
      return `${hook}\n\n${keyAngles[0]}\n\n${dataPoints.slice(0, 2).map(d => `📊 ${d.label}: ${d.value}`).join('\n')}\n\n${suggestedHashtags.slice(0, 3).join(' ')}`;
    
    case 'linkedin':
      return `${hook}\n\nKey insights:\n${keyAngles.map(a => `• ${a}`).join('\n')}\n\nThe data:\n${dataPoints.map(d => `${d.label}: ${d.value}`).join('\n')}`;
    
    case 'newsletter':
      return `📡 SIGNAL ALERT: ${brief.keyword}\n\n${hook}\n\n## Key Angles\n${keyAngles.map(a => `- ${a}`).join('\n')}\n\n## Data Points\n${dataPoints.map(d => `**${d.label}:** ${d.value}`).join('\n')}`;
    
    case 'discord':
      return `**🚨 NEW SIGNAL: ${brief.keyword}**\n\n${hook}\n\n${dataPoints.map(d => `> ${d.label}: ${d.value}`).join('\n')}\n\n*${suggestedHashtags.join(' ')}*`;
    
    default:
      return hook;
  }
}

// Utility functions
function generateId(): string {
  return `brief_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function getTimeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
  
  if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;
  return `${Math.floor(seconds / 86400)} days ago`;
}

// Export scheduled post generator
export function generateScheduledPosts(
  brief: ContentBrief,
  schedule: 'immediate' | 'peak_hours' | 'spread'
): { platform: string; content: string; scheduledTime: Date }[] {
  const now = new Date();
  const posts: { platform: string; content: string; scheduledTime: Date }[] = [];

  const peakHours = [9, 12, 17, 21]; // Common peak engagement hours

  brief.platforms.forEach((platform, index) => {
    let scheduledTime: Date;

    switch (schedule) {
      case 'immediate':
        scheduledTime = now;
        break;
      case 'peak_hours':
        const nextPeak = peakHours.find(h => h > now.getHours()) || peakHours[0];
        scheduledTime = new Date(now);
        scheduledTime.setHours(nextPeak, 0, 0, 0);
        if (nextPeak <= now.getHours()) {
          scheduledTime.setDate(scheduledTime.getDate() + 1);
        }
        break;
      case 'spread':
        scheduledTime = new Date(now.getTime() + index * 4 * 60 * 60 * 1000);
        break;
      default:
        scheduledTime = now;
    }

    posts.push({
      platform: platform.name,
      content: adaptForPlatform(brief, platform.name as any),
      scheduledTime
    });
  });

  return posts;
}
