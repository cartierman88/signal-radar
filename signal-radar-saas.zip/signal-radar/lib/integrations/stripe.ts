import Stripe from 'stripe';

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

// Plan configuration
export const PLANS = {
  FREE: {
    name: 'Free',
    price: 0,
    sources: 3,
    signals: 10,
    briefs: 5,
    dataRetention: 1, // days
    features: ['Basic signal detection', 'Email alerts', '1 day data retention'],
  },
  STARTER: {
    name: 'Starter',
    price: 29,
    priceId: process.env.STRIPE_STARTER_PRICE_ID!,
    sources: 10,
    signals: 100,
    briefs: 20,
    dataRetention: 24,
    features: [
      '10 monitored sources',
      '100 signals/month',
      '20 AI briefs/month',
      'Email alerts',
      '24h data retention',
      'Basic analytics',
    ],
  },
  PRO: {
    name: 'Pro',
    price: 99,
    priceId: process.env.STRIPE_PRO_PRICE_ID!,
    sources: 50,
    signals: -1, // Unlimited
    briefs: 100,
    dataRetention: 30,
    features: [
      '50 monitored sources',
      'Unlimited signals',
      '100 AI briefs/month',
      'Discord + Slack + Email alerts',
      '30 day data retention',
      'Advanced sentiment analysis',
      'Influencer tracking',
      'API access',
    ],
  },
  ENTERPRISE: {
    name: 'Enterprise',
    price: 299,
    priceId: process.env.STRIPE_ENTERPRISE_PRICE_ID!,
    sources: -1, // Unlimited
    signals: -1,
    briefs: -1,
    dataRetention: 90,
    seats: 5,
    features: [
      'Unlimited sources',
      'Unlimited signals',
      'Unlimited AI briefs',
      'All notification channels',
      '90 day data retention',
      'Team collaboration (5 seats)',
      'Custom integrations',
      'Dedicated support',
      'White-label reports',
    ],
  },
} as const;

export type PlanType = keyof typeof PLANS;

// Create Stripe checkout session
export async function createCheckoutSession({
  userId,
  userEmail,
  planType,
  successUrl,
  cancelUrl,
}: {
  userId: string;
  userEmail: string;
  planType: 'STARTER' | 'PRO' | 'ENTERPRISE';
  successUrl: string;
  cancelUrl: string;
}): Promise<string> {
  const plan = PLANS[planType];
  
  if (!plan.priceId) {
    throw new Error(`No price ID configured for ${planType} plan`);
  }

  const session = await stripe.checkout.sessions.create({
    customer_email: userEmail,
    client_reference_id: userId,
    payment_method_types: ['card'],
    mode: 'subscription',
    line_items: [
      {
        price: plan.priceId,
        quantity: 1,
      },
    ],
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      userId,
      planType,
    },
    subscription_data: {
      metadata: {
        userId,
        planType,
      },
    },
    allow_promotion_codes: true,
  });

  if (!session.url) {
    throw new Error('Failed to create checkout session');
  }

  return session.url;
}

// Create customer portal session for managing subscription
export async function createPortalSession({
  customerId,
  returnUrl,
}: {
  customerId: string;
  returnUrl: string;
}): Promise<string> {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });

  return session.url;
}

// Get subscription details
export async function getSubscription(subscriptionId: string): Promise<Stripe.Subscription | null> {
  try {
    return await stripe.subscriptions.retrieve(subscriptionId);
  } catch (error) {
    console.error('[Stripe] Failed to retrieve subscription:', error);
    return null;
  }
}

// Cancel subscription
export async function cancelSubscription(subscriptionId: string): Promise<Stripe.Subscription | null> {
  try {
    return await stripe.subscriptions.update(subscriptionId, {
      cancel_at_period_end: true,
    });
  } catch (error) {
    console.error('[Stripe] Failed to cancel subscription:', error);
    return null;
  }
}

// Resume cancelled subscription
export async function resumeSubscription(subscriptionId: string): Promise<Stripe.Subscription | null> {
  try {
    return await stripe.subscriptions.update(subscriptionId, {
      cancel_at_period_end: false,
    });
  } catch (error) {
    console.error('[Stripe] Failed to resume subscription:', error);
    return null;
  }
}

// Change subscription plan
export async function changeSubscriptionPlan({
  subscriptionId,
  newPriceId,
}: {
  subscriptionId: string;
  newPriceId: string;
}): Promise<Stripe.Subscription | null> {
  try {
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    
    return await stripe.subscriptions.update(subscriptionId, {
      items: [
        {
          id: subscription.items.data[0].id,
          price: newPriceId,
        },
      ],
      proration_behavior: 'create_prorations',
    });
  } catch (error) {
    console.error('[Stripe] Failed to change plan:', error);
    return null;
  }
}

// Webhook event handlers
export async function handleWebhookEvent(
  body: string | Buffer,
  signature: string
): Promise<{
  event: string;
  data: any;
} | null> {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

  try {
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        return {
          event: 'checkout.completed',
          data: {
            userId: session.metadata?.userId,
            customerId: session.customer as string,
            subscriptionId: session.subscription as string,
            planType: session.metadata?.planType,
          },
        };
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        return {
          event: 'subscription.updated',
          data: {
            subscriptionId: subscription.id,
            customerId: subscription.customer as string,
            status: subscription.status,
            currentPeriodEnd: new Date(subscription.current_period_end * 1000),
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
            priceId: subscription.items.data[0].price.id,
          },
        };
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        return {
          event: 'subscription.deleted',
          data: {
            subscriptionId: subscription.id,
            customerId: subscription.customer as string,
          },
        };
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        return {
          event: 'payment.failed',
          data: {
            customerId: invoice.customer as string,
            subscriptionId: invoice.subscription as string,
            amount: invoice.amount_due,
          },
        };
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        return {
          event: 'payment.succeeded',
          data: {
            customerId: invoice.customer as string,
            subscriptionId: invoice.subscription as string,
            amount: invoice.amount_paid,
          },
        };
      }

      default:
        return null;
    }
  } catch (error) {
    console.error('[Stripe] Webhook error:', error);
    throw error;
  }
}

// Get customer by email
export async function getCustomerByEmail(email: string): Promise<Stripe.Customer | null> {
  try {
    const customers = await stripe.customers.list({
      email,
      limit: 1,
    });

    return customers.data[0] || null;
  } catch (error) {
    console.error('[Stripe] Failed to get customer:', error);
    return null;
  }
}

// Create customer
export async function createCustomer({
  email,
  name,
  userId,
}: {
  email: string;
  name?: string;
  userId: string;
}): Promise<Stripe.Customer> {
  return await stripe.customers.create({
    email,
    name,
    metadata: {
      userId,
    },
  });
}

export { stripe };
