import { Telegraf, Context } from 'telegraf';
import { Message, Update } from 'telegraf/types';

interface TelegramMessage {
  id: number;
  text: string;
  authorId: number;
  authorUsername: string;
  authorFirstName: string;
  chatId: number;
  chatTitle: string;
  chatType: 'private' | 'group' | 'supergroup' | 'channel';
  timestamp: Date;
}

type TelegramHandler = (message: TelegramMessage) => Promise<void>;

class TelegramIntegration {
  private bot: Telegraf;
  private messageHandlers: Map<number, TelegramHandler[]> = new Map();
  private globalHandlers: TelegramHandler[] = [];
  private isRunning: boolean = false;

  constructor(token?: string) {
    const botToken = token || process.env.TELEGRAM_BOT_TOKEN;
    
    if (!botToken) {
      throw new Error('Telegram bot token not configured');
    }

    this.bot = new Telegraf(botToken);
    this.setupHandlers();
  }

  private setupHandlers() {
    // Handle text messages
    this.bot.on('text', async (ctx) => {
      const message = ctx.message;
      const chat = ctx.chat;

      const telegramMessage: TelegramMessage = {
        id: message.message_id,
        text: message.text,
        authorId: message.from.id,
        authorUsername: message.from.username || '',
        authorFirstName: message.from.first_name,
        chatId: chat.id,
        chatTitle: 'title' in chat ? chat.title : 'Private Chat',
        chatType: chat.type,
        timestamp: new Date(message.date * 1000),
      };

      // Call chat-specific handlers
      const chatHandlers = this.messageHandlers.get(chat.id);
      if (chatHandlers) {
        for (const handler of chatHandlers) {
          try {
            await handler(telegramMessage);
          } catch (error) {
            console.error('[Telegram] Chat handler error:', error);
          }
        }
      }

      // Call global handlers
      for (const handler of this.globalHandlers) {
        try {
          await handler(telegramMessage);
        } catch (error) {
          console.error('[Telegram] Global handler error:', error);
        }
      }
    });

    // Handle channel posts
    this.bot.on('channel_post', async (ctx) => {
      const post = ctx.channelPost;
      
      if (!('text' in post)) return;

      const telegramMessage: TelegramMessage = {
        id: post.message_id,
        text: post.text || '',
        authorId: 0, // Channels don't have author
        authorUsername: '',
        authorFirstName: 'Channel',
        chatId: ctx.chat.id,
        chatTitle: ctx.chat.title,
        chatType: 'channel',
        timestamp: new Date(post.date * 1000),
      };

      const chatHandlers = this.messageHandlers.get(ctx.chat.id);
      if (chatHandlers) {
        for (const handler of chatHandlers) {
          try {
            await handler(telegramMessage);
          } catch (error) {
            console.error('[Telegram] Channel handler error:', error);
          }
        }
      }

      for (const handler of this.globalHandlers) {
        try {
          await handler(telegramMessage);
        } catch (error) {
          console.error('[Telegram] Global handler error:', error);
        }
      }
    });

    // Error handling
    this.bot.catch((err, ctx) => {
      console.error('[Telegram] Bot error:', err);
    });
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('[Telegram] Bot already running');
      return;
    }

    try {
      // Use polling in development, webhook in production
      if (process.env.NODE_ENV === 'production' && process.env.TELEGRAM_WEBHOOK_URL) {
        const webhookUrl = process.env.TELEGRAM_WEBHOOK_URL;
        const secretPath = process.env.TELEGRAM_WEBHOOK_SECRET || 'signal-radar-webhook';
        
        await this.bot.telegram.setWebhook(`${webhookUrl}/${secretPath}`);
        console.log('[Telegram] Webhook set');
      } else {
        this.bot.launch();
        console.log('[Telegram] Bot started with polling');
      }
      
      this.isRunning = true;
    } catch (error) {
      console.error('[Telegram] Failed to start:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    this.bot.stop('SIGINT');
    this.isRunning = false;
  }

  // For webhook mode - handle incoming updates
  handleUpdate(update: Update): void {
    this.bot.handleUpdate(update);
  }

  subscribeToChat(chatId: number, handler: TelegramHandler): () => void {
    if (!this.messageHandlers.has(chatId)) {
      this.messageHandlers.set(chatId, []);
    }
    
    this.messageHandlers.get(chatId)!.push(handler);

    return () => {
      const handlers = this.messageHandlers.get(chatId);
      if (handlers) {
        const index = handlers.indexOf(handler);
        if (index > -1) {
          handlers.splice(index, 1);
        }
      }
    };
  }

  subscribeToAll(handler: TelegramHandler): () => void {
    this.globalHandlers.push(handler);

    return () => {
      const index = this.globalHandlers.indexOf(handler);
      if (index > -1) {
        this.globalHandlers.splice(index, 1);
      }
    };
  }

  unsubscribeFromChat(chatId: number): void {
    this.messageHandlers.delete(chatId);
  }

  async getChat(chatId: number): Promise<{
    id: number;
    title: string;
    type: string;
    memberCount?: number;
  } | null> {
    try {
      const chat = await this.bot.telegram.getChat(chatId);
      const memberCount = 'type' in chat && chat.type !== 'private' 
        ? await this.bot.telegram.getChatMembersCount(chatId)
        : undefined;

      return {
        id: chat.id,
        title: 'title' in chat ? chat.title : 'Private',
        type: chat.type,
        memberCount,
      };
    } catch (error) {
      console.error('[Telegram] Failed to get chat:', error);
      return null;
    }
  }

  async sendMessage(chatId: number, text: string): Promise<Message.TextMessage | null> {
    try {
      return await this.bot.telegram.sendMessage(chatId, text, {
        parse_mode: 'HTML',
      });
    } catch (error) {
      console.error('[Telegram] Failed to send message:', error);
      return null;
    }
  }

  async sendAlert(chatId: number, signal: {
    keyword: string;
    change: number;
    mentions: number;
    status: string;
  }): Promise<void> {
    const statusEmoji = {
      hot: '🔥',
      rising: '📈',
      emerging: '🌱',
      new: '✨',
    }[signal.status] || '📊';

    const message = `
${statusEmoji} <b>Signal Alert: ${signal.keyword}</b>

📊 <b>Change:</b> +${signal.change}% in 24h
💬 <b>Mentions:</b> ${signal.mentions.toLocaleString()}
🎯 <b>Status:</b> ${signal.status.toUpperCase()}

<a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard">View Dashboard →</a>
    `.trim();

    await this.sendMessage(chatId, message);
  }

  getStatus(): { running: boolean; chats: number; handlers: number } {
    return {
      running: this.isRunning,
      chats: this.messageHandlers.size,
      handlers: this.globalHandlers.length,
    };
  }

  // Get the bot instance for direct access if needed
  getBot(): Telegraf {
    return this.bot;
  }
}

// Singleton instance
let telegramInstance: TelegramIntegration | null = null;

export function getTelegramClient(): TelegramIntegration {
  if (!telegramInstance) {
    telegramInstance = new TelegramIntegration();
  }
  return telegramInstance;
}

export type { TelegramMessage, TelegramHandler };
export { TelegramIntegration };
