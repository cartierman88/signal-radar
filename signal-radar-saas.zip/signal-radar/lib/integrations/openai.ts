import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface SignalData {
  keyword: string;
  mentions: number;
  change24h: number;
  sentiment: number;
  sources: string[];
  influencerSeeds: number;
  trendData: number[];
  topMessages?: string[];
}

export interface GeneratedBrief {
  hook: string;
  keyAngles: string[];
  dataPoints: { label: string; value: string }[];
  suggestedHashtags: string[];
  twitterThread: string[];
  linkedinPost: string;
  newsletter: string;
}

export type BriefTone = 'professional' | 'casual' | 'urgent' | 'educational';

const TONE_INSTRUCTIONS: Record<BriefTone, string> = {
  professional: 'Use formal language suitable for business audiences. Focus on data and analysis.',
  casual: 'Use conversational language with some humor. Include emojis sparingly. Be relatable.',
  urgent: 'Create FOMO and urgency. Emphasize the time-sensitive nature. Use strong action words.',
  educational: 'Explain concepts clearly. Include definitions where needed. Focus on helping readers understand.',
};

export async function generateBrief(
  signal: SignalData,
  tone: BriefTone = 'professional'
): Promise<GeneratedBrief> {
  const systemPrompt = `You are an expert crypto content strategist who creates viral content briefs. 
You understand crypto twitter culture, DeFi narratives, and what makes content go viral.
${TONE_INSTRUCTIONS[tone]}

IMPORTANT: Return ONLY valid JSON matching the exact schema provided. No markdown, no explanations.`;

  const userPrompt = `Create a comprehensive content brief for this trending signal:

SIGNAL DATA:
- Keyword: ${signal.keyword}
- Total Mentions: ${signal.mentions.toLocaleString()}
- 24h Change: +${signal.change24h}%
- Sentiment: ${signal.sentiment}% bullish
- Sources: ${signal.sources.join(', ')}
- Influencer Seeds: ${signal.influencerSeeds}
- Trend Direction: ${signal.trendData.slice(-5).join(' → ')}
${signal.topMessages ? `\nTOP MESSAGES:\n${signal.topMessages.slice(0, 5).join('\n')}` : ''}

Generate a JSON object with this EXACT structure:
{
  "hook": "An attention-grabbing opening line (max 280 chars for Twitter)",
  "keyAngles": ["angle 1", "angle 2", "angle 3"],
  "dataPoints": [
    {"label": "Metric Name", "value": "Value with context"},
    {"label": "Another Metric", "value": "Its value"}
  ],
  "suggestedHashtags": ["#hashtag1", "#hashtag2", "#hashtag3", "#hashtag4"],
  "twitterThread": ["Tweet 1 (hook)", "Tweet 2 (context)", "Tweet 3 (data)", "Tweet 4 (insight)", "Tweet 5 (CTA)"],
  "linkedinPost": "Professional long-form post for LinkedIn (2-3 paragraphs)",
  "newsletter": "Email newsletter section with markdown formatting"
}

Return ONLY the JSON object, no other text.`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.7,
      max_tokens: 2000,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error('Empty response from OpenAI');
    }

    const brief = JSON.parse(content) as GeneratedBrief;
    
    // Validate required fields
    if (!brief.hook || !brief.keyAngles || !brief.dataPoints) {
      throw new Error('Invalid brief structure');
    }

    return brief;
  } catch (error) {
    console.error('[OpenAI] Brief generation failed:', error);
    
    // Return fallback template brief
    return generateFallbackBrief(signal);
  }
}

function generateFallbackBrief(signal: SignalData): GeneratedBrief {
  return {
    hook: `Everyone's sleeping on ${signal.keyword} while the smart money accumulates... 👀`,
    keyAngles: [
      `Early signal detected: +${signal.change24h}% spike in community discussion`,
      `${signal.influencerSeeds} influencers seeding this narrative`,
      `Multi-platform momentum across ${signal.sources.join(', ')}`,
    ],
    dataPoints: [
      { label: 'Mention Spike', value: `+${signal.change24h}% in 24h` },
      { label: 'Total Mentions', value: signal.mentions.toLocaleString() },
      { label: 'Sentiment', value: `${signal.sentiment}% bullish` },
      { label: 'Influencer Seeds', value: `${signal.influencerSeeds} detected` },
    ],
    suggestedHashtags: ['#Crypto', '#Alpha', '#DeFi', '#CryptoTwitter'],
    twitterThread: [
      `🚨 Signal Alert: ${signal.keyword}\n\nI'm seeing something brewing that most haven't noticed yet...`,
      `The data:\n\n📊 +${signal.change24h}% mention spike\n💬 ${signal.mentions.toLocaleString()} total mentions\n📈 ${signal.sentiment}% bullish sentiment`,
      `What's driving this?\n\n${signal.influencerSeeds} key influencers are seeding this narrative. When smart money starts talking, you pay attention.`,
      `The opportunity:\n\nEarly movers on emerging narratives have historically seen 10-50x returns. This is how you catch trends before they trend.`,
      `My take: Worth keeping on your radar.\n\nNFA, DYOR.\n\nFollow for more alpha. 🎯`,
    ],
    linkedinPost: `I've been tracking an interesting trend in the crypto space that's worth discussing.\n\n${signal.keyword} has seen a ${signal.change24h}% increase in community mentions over the past 24 hours, with ${signal.mentions.toLocaleString()} total discussions across ${signal.sources.length} platforms.\n\nWhat makes this notable is the quality of early adopters. ${signal.influencerSeeds} key opinion leaders have begun discussing this topic, often a leading indicator of broader market interest.\n\nFor those building in web3, keeping pulse on emerging narratives is essential for timing and positioning. The data suggests this is one to watch.`,
    newsletter: `## 🎯 Signal of the Week: ${signal.keyword}\n\n**The Numbers:**\n- 📊 **+${signal.change24h}%** mention spike in 24h\n- 💬 **${signal.mentions.toLocaleString()}** total mentions\n- 📈 **${signal.sentiment}%** bullish sentiment\n- 🎤 **${signal.influencerSeeds}** influencer seeds\n\n**What We're Seeing:**\nCommunity discussion around ${signal.keyword} is heating up across ${signal.sources.join(', ')}. The pattern matches previous breakout narratives.\n\n**Our Take:**\nWorth adding to your watchlist. Early signal, but the indicators are aligning.\n\n---\n*This is not financial advice. Always do your own research.*`,
  };
}

export async function analyzeSentiment(texts: string[]): Promise<{
  overall: number;
  distribution: { positive: number; neutral: number; negative: number };
}> {
  if (texts.length === 0) {
    return { overall: 0.5, distribution: { positive: 0, neutral: 1, negative: 0 } };
  }

  const systemPrompt = `Analyze the sentiment of crypto/trading messages. Return JSON only.`;

  const userPrompt = `Analyze sentiment for these messages:

${texts.slice(0, 20).map((t, i) => `${i + 1}. "${t.slice(0, 200)}"`).join('\n')}

Return JSON:
{
  "overall": 0.0-1.0 (0=bearish, 0.5=neutral, 1=bullish),
  "distribution": {"positive": 0.0-1.0, "neutral": 0.0-1.0, "negative": 0.0-1.0}
}`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.3,
      max_tokens: 200,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error('Empty response');

    return JSON.parse(content);
  } catch (error) {
    console.error('[OpenAI] Sentiment analysis failed:', error);
    return { overall: 0.5, distribution: { positive: 0.33, neutral: 0.34, negative: 0.33 } };
  }
}

export async function extractKeywords(text: string): Promise<string[]> {
  const systemPrompt = `Extract crypto/trading keywords from text. Return JSON array only.`;

  const userPrompt = `Extract important keywords (tokens, protocols, trends, concepts) from:

"${text.slice(0, 1000)}"

Return JSON: {"keywords": ["keyword1", "keyword2", ...]}`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.3,
      max_tokens: 200,
      response_format: { type: 'json_object' },
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error('Empty response');

    const result = JSON.parse(content);
    return result.keywords || [];
  } catch (error) {
    console.error('[OpenAI] Keyword extraction failed:', error);
    return [];
  }
}

export { openai };
