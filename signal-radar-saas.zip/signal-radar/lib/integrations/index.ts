// Platform integrations
export { getDiscordClient, DiscordIntegration } from './discord';
export type { DiscordMessage } from './discord';

export { getTwitterClient, createTwitterClient, TwitterIntegration } from './twitter';
export type { Tweet, TwitterStreamRule } from './twitter';

export { getTelegramClient, TelegramIntegration } from './telegram';
export type { TelegramMessage } from './telegram';

// Payment integration
export { 
  stripe,
  PLANS,
  createCheckoutSession,
  createPortalSession,
  getSubscription,
  cancelSubscription,
  resumeSubscription,
  changeSubscriptionPlan,
  handleWebhookEvent,
  getCustomerByEmail,
  createCustomer,
} from './stripe';
export type { PlanType } from './stripe';

// AI integration
export {
  openai,
  generateBrief,
  analyzeSentiment,
  extractKeywords,
} from './openai';
export type { SignalData, GeneratedBrief, BriefTone } from './openai';
