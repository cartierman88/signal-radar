import { Client, Events, GatewayIntentBits, Message, TextChannel } from 'discord.js';

interface DiscordMessage {
  id: string;
  content: string;
  authorId: string;
  authorName: string;
  channelId: string;
  guildId: string;
  timestamp: Date;
}

type MessageHandler = (message: DiscordMessage) => Promise<void>;

class DiscordIntegration {
  private client: Client;
  private messageHandlers: Map<string, MessageHandler[]> = new Map();
  private isReady: boolean = false;

  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
      ],
    });

    this.setupEventHandlers();
  }

  private setupEventHandlers() {
    this.client.once(Events.ClientReady, (c) => {
      console.log(`[Discord] Bot ready as ${c.user.tag}`);
      this.isReady = true;
    });

    this.client.on(Events.MessageCreate, async (message: Message) => {
      // Ignore bot messages
      if (message.author.bot) return;
      
      // Ignore DMs
      if (!message.guild) return;

      const channelId = message.channel.id;
      const handlers = this.messageHandlers.get(channelId);

      if (handlers && handlers.length > 0) {
        const discordMessage: DiscordMessage = {
          id: message.id,
          content: message.content,
          authorId: message.author.id,
          authorName: message.author.username,
          channelId: message.channel.id,
          guildId: message.guild.id,
          timestamp: message.createdAt,
        };

        for (const handler of handlers) {
          try {
            await handler(discordMessage);
          } catch (error) {
            console.error('[Discord] Handler error:', error);
          }
        }
      }
    });

    this.client.on(Events.Error, (error) => {
      console.error('[Discord] Client error:', error);
    });
  }

  async connect(token?: string): Promise<void> {
    const botToken = token || process.env.DISCORD_BOT_TOKEN;
    
    if (!botToken) {
      throw new Error('Discord bot token not configured');
    }

    try {
      await this.client.login(botToken);
    } catch (error) {
      console.error('[Discord] Login failed:', error);
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    this.client.destroy();
    this.isReady = false;
  }

  subscribeToChannel(channelId: string, handler: MessageHandler): () => void {
    if (!this.messageHandlers.has(channelId)) {
      this.messageHandlers.set(channelId, []);
    }
    
    this.messageHandlers.get(channelId)!.push(handler);

    // Return unsubscribe function
    return () => {
      const handlers = this.messageHandlers.get(channelId);
      if (handlers) {
        const index = handlers.indexOf(handler);
        if (index > -1) {
          handlers.splice(index, 1);
        }
      }
    };
  }

  unsubscribeFromChannel(channelId: string): void {
    this.messageHandlers.delete(channelId);
  }

  async fetchChannelHistory(
    channelId: string, 
    limit: number = 100
  ): Promise<DiscordMessage[]> {
    if (!this.isReady) {
      throw new Error('Discord client not ready');
    }

    try {
      const channel = await this.client.channels.fetch(channelId);
      
      if (!channel || !(channel instanceof TextChannel)) {
        throw new Error('Channel not found or not a text channel');
      }

      const messages = await channel.messages.fetch({ limit });
      
      return messages
        .filter(m => !m.author.bot)
        .map(m => ({
          id: m.id,
          content: m.content,
          authorId: m.author.id,
          authorName: m.author.username,
          channelId: m.channel.id,
          guildId: m.guild?.id || '',
          timestamp: m.createdAt,
        }));
    } catch (error) {
      console.error('[Discord] Failed to fetch history:', error);
      throw error;
    }
  }

  async getGuildChannels(guildId: string): Promise<{ id: string; name: string }[]> {
    if (!this.isReady) {
      throw new Error('Discord client not ready');
    }

    try {
      const guild = await this.client.guilds.fetch(guildId);
      const channels = await guild.channels.fetch();
      
      return channels
        .filter(c => c instanceof TextChannel)
        .map(c => ({
          id: c!.id,
          name: c!.name,
        }));
    } catch (error) {
      console.error('[Discord] Failed to fetch channels:', error);
      throw error;
    }
  }

  getStatus(): { connected: boolean; guilds: number; channels: number } {
    return {
      connected: this.isReady,
      guilds: this.client.guilds.cache.size,
      channels: this.messageHandlers.size,
    };
  }
}

// Singleton instance
let discordInstance: DiscordIntegration | null = null;

export function getDiscordClient(): DiscordIntegration {
  if (!discordInstance) {
    discordInstance = new DiscordIntegration();
  }
  return discordInstance;
}

export type { DiscordMessage, MessageHandler };
export { DiscordIntegration };
