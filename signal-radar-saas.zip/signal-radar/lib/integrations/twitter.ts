import { TwitterApi, TweetV2, UserV2 } from 'twitter-api-v2';

interface Tweet {
  id: string;
  text: string;
  authorId: string;
  authorUsername: string;
  authorFollowers: number;
  createdAt: Date;
  metrics: {
    likes: number;
    retweets: number;
    replies: number;
    quotes: number;
  };
}

interface TwitterStreamRule {
  id: string;
  value: string;
  tag?: string;
}

type TweetHandler = (tweet: Tweet) => Promise<void>;

class TwitterIntegration {
  private client: TwitterApi;
  private streamClient: TwitterApi | null = null;
  private tweetHandlers: TweetHandler[] = [];
  private isStreaming: boolean = false;
  private userCache: Map<string, UserV2> = new Map();

  constructor(bearerToken?: string) {
    const token = bearerToken || process.env.TWITTER_BEARER_TOKEN;
    
    if (!token) {
      throw new Error('Twitter bearer token not configured');
    }

    this.client = new TwitterApi(token);
  }

  private async getUserById(userId: string): Promise<UserV2 | null> {
    if (this.userCache.has(userId)) {
      return this.userCache.get(userId)!;
    }

    try {
      const user = await this.client.v2.user(userId, {
        'user.fields': ['public_metrics', 'username', 'name'],
      });
      
      if (user.data) {
        this.userCache.set(userId, user.data);
        return user.data;
      }
    } catch (error) {
      console.error('[Twitter] Failed to fetch user:', error);
    }

    return null;
  }

  private async tweetToInternal(tweet: TweetV2, includes?: any): Promise<Tweet> {
    const user = await this.getUserById(tweet.author_id || '');
    
    return {
      id: tweet.id,
      text: tweet.text,
      authorId: tweet.author_id || '',
      authorUsername: user?.username || 'unknown',
      authorFollowers: user?.public_metrics?.followers_count || 0,
      createdAt: new Date(tweet.created_at || Date.now()),
      metrics: {
        likes: tweet.public_metrics?.like_count || 0,
        retweets: tweet.public_metrics?.retweet_count || 0,
        replies: tweet.public_metrics?.reply_count || 0,
        quotes: tweet.public_metrics?.quote_count || 0,
      },
    };
  }

  async searchRecent(
    query: string,
    options: { maxResults?: number; sinceId?: string } = {}
  ): Promise<Tweet[]> {
    const { maxResults = 100, sinceId } = options;

    try {
      const results = await this.client.v2.search(query, {
        max_results: Math.min(maxResults, 100),
        since_id: sinceId,
        'tweet.fields': ['created_at', 'public_metrics', 'author_id'],
        'user.fields': ['public_metrics', 'username'],
        expansions: ['author_id'],
      });

      const tweets: Tweet[] = [];
      
      for await (const tweet of results) {
        tweets.push(await this.tweetToInternal(tweet, results.includes));
      }

      return tweets;
    } catch (error) {
      console.error('[Twitter] Search failed:', error);
      throw error;
    }
  }

  async getUserTweets(
    userId: string,
    options: { maxResults?: number; sinceId?: string } = {}
  ): Promise<Tweet[]> {
    const { maxResults = 100, sinceId } = options;

    try {
      const results = await this.client.v2.userTimeline(userId, {
        max_results: Math.min(maxResults, 100),
        since_id: sinceId,
        'tweet.fields': ['created_at', 'public_metrics', 'author_id'],
        exclude: ['retweets', 'replies'],
      });

      const tweets: Tweet[] = [];
      
      for await (const tweet of results) {
        tweets.push(await this.tweetToInternal(tweet));
      }

      return tweets;
    } catch (error) {
      console.error('[Twitter] Failed to fetch user tweets:', error);
      throw error;
    }
  }

  async getListTweets(
    listId: string,
    options: { maxResults?: number } = {}
  ): Promise<Tweet[]> {
    const { maxResults = 100 } = options;

    try {
      const results = await this.client.v2.listTweets(listId, {
        max_results: Math.min(maxResults, 100),
        'tweet.fields': ['created_at', 'public_metrics', 'author_id'],
        'user.fields': ['public_metrics', 'username'],
        expansions: ['author_id'],
      });

      const tweets: Tweet[] = [];
      
      for await (const tweet of results) {
        tweets.push(await this.tweetToInternal(tweet, results.includes));
      }

      return tweets;
    } catch (error) {
      console.error('[Twitter] Failed to fetch list tweets:', error);
      throw error;
    }
  }

  async addStreamRule(rule: string, tag?: string): Promise<TwitterStreamRule> {
    try {
      const result = await this.client.v2.updateStreamRules({
        add: [{ value: rule, tag }],
      });

      if (result.errors && result.errors.length > 0) {
        throw new Error(result.errors[0].detail);
      }

      return {
        id: result.data[0].id,
        value: result.data[0].value,
        tag: result.data[0].tag,
      };
    } catch (error) {
      console.error('[Twitter] Failed to add stream rule:', error);
      throw error;
    }
  }

  async removeStreamRule(ruleId: string): Promise<void> {
    try {
      await this.client.v2.updateStreamRules({
        delete: { ids: [ruleId] },
      });
    } catch (error) {
      console.error('[Twitter] Failed to remove stream rule:', error);
      throw error;
    }
  }

  async getStreamRules(): Promise<TwitterStreamRule[]> {
    try {
      const rules = await this.client.v2.streamRules();
      
      return (rules.data || []).map(rule => ({
        id: rule.id,
        value: rule.value,
        tag: rule.tag,
      }));
    } catch (error) {
      console.error('[Twitter] Failed to get stream rules:', error);
      throw error;
    }
  }

  subscribeToStream(handler: TweetHandler): () => void {
    this.tweetHandlers.push(handler);

    // Return unsubscribe function
    return () => {
      const index = this.tweetHandlers.indexOf(handler);
      if (index > -1) {
        this.tweetHandlers.splice(index, 1);
      }
    };
  }

  async startStream(): Promise<void> {
    if (this.isStreaming) {
      console.log('[Twitter] Stream already running');
      return;
    }

    try {
      const stream = await this.client.v2.searchStream({
        'tweet.fields': ['created_at', 'public_metrics', 'author_id'],
        'user.fields': ['public_metrics', 'username'],
        expansions: ['author_id'],
        autoConnect: true,
      });

      this.isStreaming = true;

      stream.on('data', async (data) => {
        if (data.data) {
          const tweet = await this.tweetToInternal(data.data, data.includes);
          
          for (const handler of this.tweetHandlers) {
            try {
              await handler(tweet);
            } catch (error) {
              console.error('[Twitter] Handler error:', error);
            }
          }
        }
      });

      stream.on('error', (error) => {
        console.error('[Twitter] Stream error:', error);
        this.isStreaming = false;
      });

      stream.on('close', () => {
        console.log('[Twitter] Stream closed');
        this.isStreaming = false;
      });

    } catch (error) {
      console.error('[Twitter] Failed to start stream:', error);
      this.isStreaming = false;
      throw error;
    }
  }

  stopStream(): void {
    this.isStreaming = false;
    // Stream will close on its own when garbage collected
  }

  async lookupUser(username: string): Promise<UserV2 | null> {
    try {
      const user = await this.client.v2.userByUsername(username, {
        'user.fields': ['public_metrics', 'description', 'profile_image_url'],
      });
      
      return user.data || null;
    } catch (error) {
      console.error('[Twitter] Failed to lookup user:', error);
      return null;
    }
  }

  getStatus(): { streaming: boolean; handlers: number; rules: number } {
    return {
      streaming: this.isStreaming,
      handlers: this.tweetHandlers.length,
      rules: 0, // Would need to fetch async
    };
  }
}

// Factory function for creating clients
export function createTwitterClient(bearerToken?: string): TwitterIntegration {
  return new TwitterIntegration(bearerToken);
}

// Singleton for server-side use
let twitterInstance: TwitterIntegration | null = null;

export function getTwitterClient(): TwitterIntegration {
  if (!twitterInstance) {
    twitterInstance = new TwitterIntegration();
  }
  return twitterInstance;
}

export type { Tweet, TwitterStreamRule, TweetHandler };
export { TwitterIntegration };
