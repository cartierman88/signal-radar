import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Signal Radar - Catch Crypto Trends 48 Hours Early',
  description: 'Monitor Discord, X, and Telegram to detect rising crypto narratives before they hit your timeline. Get AI-powered briefs to publish first.',
  keywords: 'crypto, trading, signals, discord, twitter, telegram, AI, trends, alpha',
  openGraph: {
    title: 'Signal Radar - Catch Crypto Trends 48 Hours Early',
    description: 'Monitor Discord, X, and Telegram to detect rising crypto narratives before they hit your timeline.',
    images: ['/og-image.png'],
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Signal Radar',
    description: 'Catch crypto trends 48 hours before mainstream',
    images: ['/og-image.png'],
  },
};

export default function MarketingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
