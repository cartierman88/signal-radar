'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Zap, TrendingUp, MessageSquare, FileText, 
  Check, ArrowRight, Twitter, Send, ChevronDown,
  Sparkles, Shield, Clock, Users, BarChart3, Bell
} from 'lucide-react';

// Animated counter hook
function useCounter(end: number, duration: number = 2000) {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    let startTime: number;
    let animationFrame: number;
    
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };
    
    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration]);
  
  return count;
}

// Radar animation component
function RadarAnimation() {
  return (
    <div className="relative w-[400px] h-[400px] mx-auto">
      {/* Grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.05)_1px,transparent_1px)] bg-[size:40px_40px]" />
      
      {/* Radar circles */}
      {[100, 75, 50, 25].map((size, i) => (
        <div 
          key={i}
          className="absolute border border-cyan-400/20 rounded-full left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ width: `${size}%`, height: `${size}%` }}
        />
      ))}
      
      {/* Center pulse */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-cyan-400 rounded-full animate-ping" />
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-cyan-400 rounded-full" />
      
      {/* Sweep line */}
      <div className="absolute w-1/2 h-0.5 bg-gradient-to-r from-cyan-400 to-transparent left-1/2 top-1/2 origin-left animate-sweep" />
      
      {/* Signal blips */}
      <div className="absolute left-[25%] top-[20%] animate-float" style={{ animationDelay: '0s' }}>
        <div className="relative">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
          <span className="absolute left-5 top-0 text-xs font-mono text-red-400 whitespace-nowrap">$VIRTUAL +340%</span>
        </div>
      </div>
      
      <div className="absolute left-[70%] top-[35%] animate-float" style={{ animationDelay: '0.5s' }}>
        <div className="relative">
          <div className="w-3 h-3 bg-orange-500 rounded-full animate-pulse" />
          <span className="absolute left-5 top-0 text-xs font-mono text-orange-400 whitespace-nowrap">AI Agents +127%</span>
        </div>
      </div>
      
      <div className="absolute left-[35%] top-[65%] animate-float" style={{ animationDelay: '1s' }}>
        <div className="relative">
          <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse" />
          <span className="absolute left-5 top-0 text-xs font-mono text-cyan-400 whitespace-nowrap">MCP Protocol +78%</span>
        </div>
      </div>
      
      <div className="absolute left-[65%] top-[75%] animate-float" style={{ animationDelay: '1.5s' }}>
        <div className="relative">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
          <span className="absolute left-5 top-0 text-xs font-mono text-green-400 whitespace-nowrap">Restaking +56%</span>
        </div>
      </div>
    </div>
  );
}

// Social proof ticker
function SocialProofTicker() {
  const items = [
    { name: 'Alex', action: 'caught $VIRTUAL 48hrs early', gain: '+847%' },
    { name: 'Sarah', action: 'spotted Base migration trend', gain: '+234%' },
    { name: 'Mike', action: 'detected AI agents narrative', gain: '+567%' },
    { name: 'Jordan', action: 'found MCP before CT', gain: '+189%' },
    { name: 'Chris', action: 'identified restaking meta', gain: '+423%' },
  ];

  return (
    <div className="overflow-hidden py-4 border-y border-white/5">
      <div className="flex animate-[scroll_20s_linear_infinite]">
        {[...items, ...items].map((item, i) => (
          <div key={i} className="flex items-center gap-2 px-6 whitespace-nowrap">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center text-xs font-bold">
              {item.name[0]}
            </div>
            <span className="text-text-secondary">{item.name} {item.action}</span>
            <span className="text-green-500 font-mono font-bold">{item.gain}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// Feature card
function FeatureCard({ icon: Icon, title, description }: { 
  icon: any; 
  title: string; 
  description: string;
}) {
  return (
    <div className="group p-6 bg-bg-secondary border border-white/5 rounded-2xl hover:border-cyan-400/30 transition-all hover:-translate-y-1">
      <div className="w-12 h-12 rounded-xl bg-cyan-400/10 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-text-secondary text-sm">{description}</p>
    </div>
  );
}

// Pricing card
function PricingCard({ 
  name, 
  price, 
  period,
  description, 
  features, 
  cta, 
  popular,
  href
}: { 
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  cta: string;
  popular?: boolean;
  href: string;
}) {
  return (
    <div className={`relative p-8 rounded-2xl border ${
      popular 
        ? 'bg-gradient-to-b from-cyan-400/10 to-purple-500/10 border-cyan-400/30' 
        : 'bg-bg-secondary border-white/5'
    }`}>
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full text-xs font-bold text-white">
          MOST POPULAR
        </div>
      )}
      
      <h3 className="text-xl font-bold mb-2">{name}</h3>
      <p className="text-text-secondary text-sm mb-4">{description}</p>
      
      <div className="mb-6">
        <span className="text-4xl font-bold font-mono">{price}</span>
        <span className="text-text-muted">/{period}</span>
      </div>
      
      <ul className="space-y-3 mb-8">
        {features.map((feature, i) => (
          <li key={i} className="flex items-center gap-3 text-sm">
            <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      
      <Link 
        href={href}
        className={`w-full py-3 px-6 rounded-xl font-semibold text-center flex items-center justify-center gap-2 transition-all ${
          popular
            ? 'bg-gradient-to-r from-cyan-400 to-purple-500 text-white hover:opacity-90'
            : 'bg-bg-tertiary text-white border border-white/10 hover:border-cyan-400/50'
        }`}
      >
        {cta}
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}

// Testimonial
function Testimonial({ quote, author, role, avatar }: {
  quote: string;
  author: string;
  role: string;
  avatar: string;
}) {
  return (
    <div className="p-6 bg-bg-secondary border border-white/5 rounded-2xl">
      <p className="text-text-secondary mb-4 italic">"{quote}"</p>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center text-sm font-bold">
          {avatar}
        </div>
        <div>
          <p className="font-semibold text-sm">{author}</p>
          <p className="text-text-muted text-xs">{role}</p>
        </div>
      </div>
    </div>
  );
}

// FAQ Item
function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="border-b border-white/5">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-5 flex items-center justify-between text-left"
      >
        <span className="font-medium">{question}</span>
        <ChevronDown className={`w-5 h-5 text-text-muted transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="pb-5 text-text-secondary text-sm">
          {answer}
        </div>
      )}
    </div>
  );
}

// Main Landing Page
export default function LandingPage() {
  const signalsDetected = useCounter(12847);
  const hoursAhead = useCounter(48);
  const activeUsers = useCounter(2341);

  return (
    <div className="min-h-screen bg-bg-primary text-text-primary">
      {/* Scanlines overlay */}
      <div className="fixed inset-0 pointer-events-none bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,0,0,0.1)_2px,rgba(0,0,0,0.1)_4px)] opacity-30 z-50" />
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-bg-primary/80 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center animate-pulse-glow">
              <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"/>
                <circle cx="12" cy="12" r="6"/>
                <circle cx="12" cy="12" r="2"/>
              </svg>
            </div>
            <span className="text-xl font-bold">Signal<span className="text-cyan-400">Radar</span></span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm text-text-secondary">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </div>
          
          <div className="flex items-center gap-4">
            <Link href="/login" className="text-sm text-text-secondary hover:text-white transition-colors">
              Log in
            </Link>
            <Link href="/signup" className="px-5 py-2 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity">
              Start Free Trial
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-400/10 border border-cyan-400/20 rounded-full text-cyan-400 text-sm font-mono mb-6">
                <Sparkles className="w-4 h-4" />
                <span>Catch trends 48 hours early</span>
              </div>
              
              {/* Headline */}
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight mb-6">
                I caught the trend{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                  48 hours before
                </span>{' '}
                it went mainstream
              </h1>
              
              {/* Subheadline */}
              <p className="text-xl text-text-secondary mb-8 leading-relaxed">
                Signal Radar monitors Discord, X, and Telegram to detect rising crypto narratives 
                before they hit your timeline. Get AI-powered briefs to publish first and own the conversation.
              </p>
              
              {/* CTA buttons */}
              <div className="flex flex-wrap gap-4 mb-8">
                <Link 
                  href="/signup"
                  className="px-8 py-4 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-xl font-semibold text-lg flex items-center gap-2 hover:opacity-90 transition-all hover:-translate-y-0.5"
                >
                  Start Free Trial
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <a 
                  href="#demo"
                  className="px-8 py-4 bg-bg-secondary border border-white/10 rounded-xl font-semibold text-lg hover:border-cyan-400/50 transition-all"
                >
                  Watch Demo
                </a>
              </div>
              
              {/* Trust indicators */}
              <div className="flex items-center gap-6 text-sm text-text-muted">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  No credit card required
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  7-day free trial
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" />
                  Cancel anytime
                </div>
              </div>
            </div>
            
            {/* Radar visualization */}
            <div className="hidden lg:block">
              <RadarAnimation />
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="py-12 border-y border-white/5 bg-bg-secondary/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-3 gap-8 text-center">
            <div>
              <p className="text-4xl font-bold font-mono text-cyan-400">{signalsDetected.toLocaleString()}+</p>
              <p className="text-text-secondary text-sm mt-1">Signals detected this month</p>
            </div>
            <div>
              <p className="text-4xl font-bold font-mono text-orange-500">{hoursAhead}h</p>
              <p className="text-text-secondary text-sm mt-1">Average lead time on trends</p>
            </div>
            <div>
              <p className="text-4xl font-bold font-mono text-green-500">{activeUsers.toLocaleString()}+</p>
              <p className="text-text-secondary text-sm mt-1">Active alpha hunters</p>
            </div>
          </div>
        </div>
      </section>

      {/* Social proof ticker */}
      <SocialProofTicker />

      {/* Features Section */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Turn noise into{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                actionable intelligence
              </span>
            </h2>
            <p className="text-text-secondary text-lg max-w-2xl mx-auto">
              Stop scrolling through thousands of messages. Let AI surface what matters and generate content that positions you as the expert.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard 
              icon={BarChart3}
              title="Keyword Spike Detection"
              description="Track when specific tokens, protocols, or narratives suddenly surge in community discussions before they trend."
            />
            <FeatureCard 
              icon={Users}
              title="Influencer Seed Tracking"
              description="Detect when key influencers first mention emerging topics. Be there before their audience amplifies it."
            />
            <FeatureCard 
              icon={TrendingUp}
              title="Sentiment Analysis"
              description="Understand if the community is bullish, bearish, or uncertain. Make informed calls with real-time sentiment scores."
            />
            <FeatureCard 
              icon={MessageSquare}
              title="Recurring Question Detection"
              description="Find what the community keeps asking about. Create FAQ content that captures search traffic."
            />
            <FeatureCard 
              icon={FileText}
              title="AI Brief Generator"
              description="Get instant content briefs with hooks, key angles, data points, and platform-optimized copy. Publish in minutes."
            />
            <FeatureCard 
              icon={Bell}
              title="Real-Time Alerts"
              description="Get notified via Discord, Slack, Telegram, or email when signals cross your thresholds. Never miss alpha."
            />
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-6 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">How it works</h2>
            <p className="text-text-secondary text-lg">From noise to published content in 4 simple steps</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: '01', title: 'Connect Sources', desc: 'Link your Discord servers, Twitter lists, and Telegram groups' },
              { step: '02', title: 'AI Monitors 24/7', desc: 'Our engine analyzes every message for emerging signals' },
              { step: '03', title: 'Get Alerts', desc: 'Receive instant notifications when trends spike' },
              { step: '04', title: 'Publish First', desc: 'Generate briefs and post before anyone else' },
            ].map((item, i) => (
              <div key={i} className="relative">
                <div className="text-6xl font-bold font-mono text-cyan-400/20 mb-4">{item.step}</div>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-text-secondary text-sm">{item.desc}</p>
                {i < 3 && (
                  <ArrowRight className="hidden md:block absolute top-8 -right-4 w-8 h-8 text-cyan-400/30" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Simple pricing for{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
                every alpha hunter
              </span>
            </h2>
            <p className="text-text-secondary text-lg">Start free. Upgrade when you need more power.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <PricingCard 
              name="Starter"
              price="$29"
              period="month"
              description="Perfect for solo content creators"
              features={[
                '10 monitored sources',
                '100 signals/month',
                '20 AI briefs/month',
                'Email alerts',
                '24h data retention',
                'Basic analytics',
              ]}
              cta="Start Free Trial"
              href="/signup?plan=starter"
            />
            
            <PricingCard 
              name="Pro"
              price="$99"
              period="month"
              description="For serious traders & researchers"
              features={[
                '50 monitored sources',
                'Unlimited signals',
                '100 AI briefs/month',
                'Discord + Slack + Email alerts',
                '30 day data retention',
                'Advanced sentiment analysis',
                'Influencer tracking',
                'API access',
              ]}
              cta="Start Free Trial"
              href="/signup?plan=pro"
              popular
            />
            
            <PricingCard 
              name="Enterprise"
              price="$299"
              period="month"
              description="For teams & agencies"
              features={[
                'Unlimited sources',
                'Unlimited signals',
                'Unlimited AI briefs',
                'All notification channels',
                '90 day data retention',
                'Team collaboration (5 seats)',
                'Custom integrations',
                'Dedicated support',
                'White-label reports',
              ]}
              cta="Contact Sales"
              href="/contact"
            />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Trusted by alpha hunters</h2>
            <p className="text-text-secondary text-lg">See what our community is saying</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <Testimonial 
              quote="Signal Radar caught the $VIRTUAL meta 2 days before CT. My thread got 500K impressions. Worth every penny."
              author="Alex Chen"
              role="Crypto Researcher"
              avatar="A"
            />
            <Testimonial 
              quote="I used to spend 4 hours daily in Discord. Now I get a morning briefing and publish before breakfast. Game changer."
              author="Sarah Kim"
              role="Content Creator"
              avatar="S"
            />
            <Testimonial 
              quote="The influencer seed detection is insane. I know what big accounts are talking about before their tweets go live."
              author="Mike Davis"
              role="Trader"
              avatar="M"
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">Frequently asked questions</h2>
            <p className="text-text-secondary text-lg">Everything you need to know</p>
          </div>
          
          <div>
            <FAQItem 
              question="How does the 7-day free trial work?"
              answer="You get full access to all Pro features for 7 days, no credit card required. If you decide to continue, you can upgrade to any paid plan. Otherwise, you'll be downgraded to a limited free tier."
            />
            <FAQItem 
              question="What sources can I monitor?"
              answer="You can connect Discord servers (via our bot), Twitter/X accounts and lists (via API), and Telegram groups and channels (via our bot). We're adding Reddit, Farcaster, and Lens soon."
            />
            <FAQItem 
              question="How accurate is the signal detection?"
              answer="Our AI has been trained on millions of crypto messages. We detect keyword spikes with 94% accuracy and sentiment shifts with 87% accuracy. False positives are filtered using multi-source validation."
            />
            <FAQItem 
              question="Can I export the data?"
              answer="Yes! Pro and Enterprise plans include API access and CSV exports. You can integrate Signal Radar with your existing tools and workflows."
            />
            <FAQItem 
              question="Is my data private?"
              answer="Absolutely. We only analyze messages from communities you explicitly connect. Your signals and briefs are private to your account. We never sell data and are fully GDPR compliant."
            />
            <FAQItem 
              question="What if I need more sources?"
              answer="Contact us for custom Enterprise pricing if you need more than the standard limits. We can scale to thousands of sources for larger operations."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="p-12 bg-gradient-to-br from-cyan-400/10 to-purple-500/10 border border-cyan-400/20 rounded-3xl">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Ready to catch trends before they trend?
            </h2>
            <p className="text-text-secondary text-lg mb-8 max-w-2xl mx-auto">
              Join 2,000+ alpha hunters who are publishing first. Start your free trial today.
            </p>
            <Link 
              href="/signup"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-xl font-semibold text-lg hover:opacity-90 transition-all hover:-translate-y-0.5"
            >
              Start Free Trial
              <ArrowRight className="w-5 h-5" />
            </Link>
            <p className="text-text-muted text-sm mt-4">No credit card required • 7-day free trial</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10"/>
                    <circle cx="12" cy="12" r="6"/>
                    <circle cx="12" cy="12" r="2"/>
                  </svg>
                </div>
                <span className="font-bold">Signal<span className="text-cyan-400">Radar</span></span>
              </div>
              <p className="text-text-secondary text-sm">
                Detect rising crypto narratives 48 hours before mainstream.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-text-secondary">
                <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="/changelog" className="hover:text-white transition-colors">Changelog</a></li>
                <li><a href="/docs" className="hover:text-white transition-colors">API Docs</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-text-secondary">
                <li><a href="/about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="/blog" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="/careers" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="/contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-text-secondary">
                <li><a href="/privacy" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="/terms" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="/security" className="hover:text-white transition-colors">Security</a></li>
              </ul>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/5">
            <p className="text-text-muted text-sm">© 2024 SignalRadar. All rights reserved.</p>
            <div className="flex items-center gap-4 mt-4 md:mt-0">
              <a href="https://twitter.com/signalradar" className="text-text-muted hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="https://t.me/signalradar" className="text-text-muted hover:text-white transition-colors">
                <Send className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Add scroll animation for ticker */}
      <style jsx global>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
