import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Dashboard | Signal Radar',
  description: 'Your real-time crypto signal monitoring dashboard',
};

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // In production, wrap with auth check:
  // const session = await getServerSession(authOptions);
  // if (!session) redirect('/login');
  
  return children;
}
