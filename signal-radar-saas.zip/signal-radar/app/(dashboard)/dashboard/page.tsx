'use client';

import { useState, useEffect } from 'react';
import { 
  Zap, TrendingUp, MessageSquare, FileText, 
  Settings, Bell, Grid, Clock, Calendar,
  ChevronRight, Copy, Check, Plus
} from 'lucide-react';

// Types
interface Signal {
  id: string;
  keyword: string;
  status: 'hot' | 'rising' | 'emerging' | 'new';
  mentions: number;
  change24h: number;
  sentiment: number;
  influencerSeeds: number;
  sources: string[];
  trendData: number[];
}

interface ContentBrief {
  hook: string;
  keyAngles: string[];
  dataPoints: { label: string; value: string }[];
  suggestedHashtags: string[];
}

// Mock data
const mockSignals: Signal[] = [
  {
    id: '1',
    keyword: '$VIRTUAL agents',
    status: 'hot',
    mentions: 2847,
    change24h: 340,
    sentiment: 78,
    influencerSeeds: 12,
    sources: ['discord', 'twitter', 'telegram'],
    trendData: [20, 25, 30, 35, 28, 45, 55, 70, 85, 100]
  },
  {
    id: '2',
    keyword: 'Base chain migration',
    status: 'rising',
    mentions: 1203,
    change24h: 127,
    sentiment: 72,
    influencerSeeds: 7,
    sources: ['discord', 'twitter'],
    trendData: [15, 20, 18, 25, 35, 50, 60, 75, 70, 85]
  },
  {
    id: '3',
    keyword: 'MCP protocol',
    status: 'emerging',
    mentions: 487,
    change24h: 78,
    sentiment: 82,
    influencerSeeds: 3,
    sources: ['twitter', 'telegram'],
    trendData: [10, 12, 15, 20, 28, 35, 45, 52, 60, 68]
  },
  {
    id: '4',
    keyword: 'Solana restaking',
    status: 'rising',
    mentions: 892,
    change24h: 95,
    sentiment: 69,
    influencerSeeds: 5,
    sources: ['discord', 'twitter', 'telegram'],
    trendData: [25, 30, 28, 40, 45, 55, 65, 58, 72, 80]
  },
  {
    id: '5',
    keyword: 'AI agents trading',
    status: 'emerging',
    mentions: 324,
    change24h: 56,
    sentiment: 74,
    influencerSeeds: 2,
    sources: ['twitter'],
    trendData: [8, 12, 10, 18, 22, 30, 38, 42, 48, 55]
  }
];

// Components
function Sidebar() {
  const [activeNav, setActiveNav] = useState('dashboard');
  
  const navItems = [
    { id: 'dashboard', icon: Grid, label: 'Dashboard' },
    { id: 'signals', icon: Zap, label: 'Signals', badge: 12 },
    { id: 'history', icon: Clock, label: 'History' },
  ];

  const toolItems = [
    { id: 'briefs', icon: FileText, label: 'Brief Generator' },
    { id: 'scheduler', icon: Calendar, label: 'Scheduler' },
  ];

  const settingItems = [
    { id: 'sources', icon: Settings, label: 'Sources' },
    { id: 'alerts', icon: Bell, label: 'Alerts' },
  ];

  return (
    <aside className="w-[260px] bg-[var(--bg-secondary)] border-r border-[var(--border-color)] p-6 flex flex-col fixed h-screen z-50">
      {/* Logo */}
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center animate-pulse-glow">
          <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10"/>
            <circle cx="12" cy="12" r="6"/>
            <circle cx="12" cy="12" r="2"/>
          </svg>
        </div>
        <span className="text-lg font-bold">Signal<span className="text-cyan-400">Radar</span></span>
      </div>

      {/* Navigation */}
      <nav className="flex-1">
        <div className="mb-6">
          <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)] font-mono px-3 mb-2">Main</p>
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-all ${
                activeNav === item.id 
                  ? 'bg-cyan-400/10 text-cyan-400' 
                  : 'text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
              {item.badge && (
                <span className="ml-auto bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-mono">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="mb-6">
          <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)] font-mono px-3 mb-2">Tools</p>
          {toolItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-all ${
                activeNav === item.id 
                  ? 'bg-cyan-400/10 text-cyan-400' 
                  : 'text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </div>

        <div>
          <p className="text-[11px] uppercase tracking-wider text-[var(--text-muted)] font-mono px-3 mb-2">Settings</p>
          {settingItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-all ${
                activeNav === item.id 
                  ? 'bg-cyan-400/10 text-cyan-400' 
                  : 'text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Plan Info */}
      <div className="p-4 bg-[var(--bg-tertiary)] rounded-xl">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-cyan-400 font-mono">PRO PLAN</span>
          <span className="text-[11px] text-[var(--text-muted)]">67/100 sources</span>
        </div>
        <div className="h-1 bg-[var(--bg-primary)] rounded-full overflow-hidden">
          <div className="h-full w-[67%] bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full" />
        </div>
      </div>
    </aside>
  );
}

function StatCard({ label, value, change, icon: Icon, color }: { 
  label: string; 
  value: string; 
  change: string; 
  icon: any; 
  color: 'cyan' | 'green' | 'orange' | 'purple';
}) {
  const colors = {
    cyan: 'bg-cyan-400/10 text-cyan-400',
    green: 'bg-green-500/10 text-green-500',
    orange: 'bg-orange-500/10 text-orange-500',
    purple: 'bg-purple-500/10 text-purple-500',
  };

  return (
    <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-xl p-5 relative overflow-hidden group">
      <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-[var(--text-secondary)]">{label}</span>
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-[18px] h-[18px]" />
        </div>
      </div>
      <p className="text-3xl font-bold font-mono tracking-tight">{value}</p>
      <p className="text-xs text-green-500 mt-2 flex items-center gap-1">
        <TrendingUp className="w-3 h-3" />
        {change}
      </p>
    </div>
  );
}

function SignalCard({ signal, onClick }: { signal: Signal; onClick: () => void }) {
  const statusColors = {
    hot: 'bg-red-500',
    rising: 'bg-orange-500',
    emerging: 'bg-cyan-400',
    new: 'bg-green-500',
  };

  const statusBadge = {
    hot: { bg: 'bg-red-500/10', text: 'text-red-500', label: '🔥 HOT' },
    rising: { bg: 'bg-orange-500/10', text: 'text-orange-500', label: '📈 RISING' },
    emerging: { bg: 'bg-cyan-400/10', text: 'text-cyan-400', label: '🌱 EMERGING' },
    new: { bg: 'bg-green-500/10', text: 'text-green-500', label: '✨ NEW' },
  };

  return (
    <div 
      onClick={onClick}
      className="bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-xl p-4 cursor-pointer transition-all hover:border-cyan-400 hover:translate-x-1 relative"
    >
      <div className={`absolute left-0 top-0 bottom-0 w-[3px] rounded-l-xl ${statusColors[signal.status]}`} />
      
      <div className="flex items-start justify-between mb-3">
        <span className="font-semibold font-mono">{signal.keyword}</span>
        <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase font-mono ${statusBadge[signal.status].bg} ${statusBadge[signal.status].text}`}>
          {statusBadge[signal.status].label}
        </span>
      </div>

      <div className="flex items-center gap-4 text-xs text-[var(--text-secondary)] mb-3">
        <span className="flex items-center gap-1">📊 {signal.mentions.toLocaleString()} mentions</span>
        <span className="flex items-center gap-1">⏱️ +{signal.change24h}% / 24h</span>
      </div>

      <div className="flex gap-1.5 mb-3">
        {signal.sources.map(source => (
          <span 
            key={source}
            className={`px-2 py-1 rounded text-[10px] font-medium font-mono ${
              source === 'discord' ? 'bg-[#5865F2] text-white' :
              source === 'twitter' ? 'bg-[#1DA1F2] text-white' :
              'bg-[#0088cc] text-white'
            }`}
          >
            {source.charAt(0).toUpperCase() + source.slice(1)}
          </span>
        ))}
      </div>

      <div className="flex items-end gap-0.5 h-10">
        {signal.trendData.map((val, i) => (
          <div 
            key={i}
            className="flex-1 bg-cyan-400 rounded-t opacity-60 hover:opacity-100 transition-opacity"
            style={{ height: `${val}%` }}
          />
        ))}
      </div>
    </div>
  );
}

function RadarVisualization() {
  return (
    <div className="flex flex-col items-center p-6">
      <div className="w-[280px] h-[280px] relative mb-6">
        {/* Radar circles */}
        {[100, 75, 50, 25].map((size, i) => (
          <div 
            key={i}
            className="absolute border border-[var(--border-color)] rounded-full left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
            style={{ width: `${size}%`, height: `${size}%` }}
          />
        ))}
        
        {/* Sweep line */}
        <div className="absolute w-1/2 h-0.5 bg-gradient-to-r from-cyan-400 to-transparent left-1/2 top-1/2 origin-left animate-sweep" />
        
        {/* Blips */}
        <div className="absolute w-3 h-3 rounded-full bg-red-500 left-[30%] top-[25%] animate-blip" />
        <div className="absolute w-3 h-3 rounded-full bg-orange-500 left-[70%] top-[40%] animate-blip" style={{ animationDelay: '0.5s' }} />
        <div className="absolute w-3 h-3 rounded-full bg-cyan-400 left-[45%] top-[65%] animate-blip" style={{ animationDelay: '1s' }} />
        <div className="absolute w-3 h-3 rounded-full bg-green-500 left-[60%] top-[75%] animate-blip" style={{ animationDelay: '1.5s' }} />
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 justify-center text-xs text-[var(--text-secondary)]">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-red-500" />
          Hot (&gt;200%)
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-orange-500" />
          Rising (100-200%)
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400" />
          Emerging (50-100%)
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          New (&lt;50%)
        </div>
      </div>
    </div>
  );
}

function BriefGenerator({ signal }: { signal: Signal | null }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [brief, setBrief] = useState<ContentBrief | null>(null);
  const [copied, setCopied] = useState(false);

  const generateBrief = async () => {
    if (!signal) return;
    
    setIsGenerating(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setBrief({
      hook: `Everyone's sleeping on ${signal.keyword} while the smart money accumulates...`,
      keyAngles: [
        'First-mover in autonomous agent tokens',
        'Integration with major DeFi protocols',
        'Community governance via agent DAOs'
      ],
      dataPoints: [
        { label: 'Mention spike', value: `+${signal.change24h}% in 24h` },
        { label: 'Total mentions', value: signal.mentions.toLocaleString() },
        { label: 'Sentiment', value: `${signal.sentiment}% bullish` },
        { label: 'Influencer seeds', value: `${signal.influencerSeeds} detected` }
      ],
      suggestedHashtags: ['#AIAgents', '#DeFi', '#Alpha', '#CryptoTwitter']
    });
    
    setIsGenerating(false);
  };

  const copyBrief = () => {
    if (!brief) return;
    navigator.clipboard.writeText(
      `${brief.hook}\n\n${brief.keyAngles.map(a => `• ${a}`).join('\n')}\n\n${brief.dataPoints.map(d => `${d.label}: ${d.value}`).join('\n')}\n\n${brief.suggestedHashtags.join(' ')}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-5">
      <div className="mb-4">
        <label className="block text-xs text-[var(--text-secondary)] font-mono mb-2">SELECT SIGNAL</label>
        <select className="w-full p-3 bg-[var(--bg-tertiary)] border border-[var(--border-color)] rounded-lg text-sm focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 outline-none">
          {mockSignals.map(s => (
            <option key={s.id} value={s.id}>
              {s.keyword} (+{s.change24h}%)
            </option>
          ))}
        </select>
      </div>

      <button 
        onClick={generateBrief}
        disabled={isGenerating}
        className="w-full btn btn-primary mb-4 disabled:opacity-50"
      >
        {isGenerating ? 'Generating...' : 'Generate Brief →'}
      </button>

      {brief && (
        <div className="bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-xl p-4">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-semibold text-cyan-400 font-mono">// GENERATED BRIEF</span>
            <button 
              onClick={copyBrief}
              className="p-2 hover:bg-[var(--bg-tertiary)] rounded transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="text-sm text-[var(--text-secondary)] space-y-4">
            <div>
              <h4 className="text-xs font-mono text-white mb-2">📌 HOOK</h4>
              <p>"{brief.hook}"</p>
            </div>

            <div>
              <h4 className="text-xs font-mono text-white mb-2">🎯 KEY ANGLES</h4>
              <ul className="space-y-1">
                {brief.keyAngles.map((angle, i) => (
                  <li key={i}>• {angle}</li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-mono text-white mb-2">📊 DATA POINTS</h4>
              <ul className="space-y-1">
                {brief.dataPoints.map((dp, i) => (
                  <li key={i}>• {dp.label}: {dp.value}</li>
                ))}
              </ul>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              {brief.suggestedHashtags.map((tag, i) => (
                <span key={i} className="px-2 py-1 bg-purple-500/10 text-purple-400 rounded text-xs font-mono">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed bottom-6 right-6 bg-[var(--bg-secondary)] border border-green-500 rounded-xl p-4 flex items-center gap-3 shadow-lg shadow-green-500/20 animate-slide-in z-50">
      <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center text-green-500">
        <Zap className="w-4 h-4" />
      </div>
      <div>
        <h4 className="text-sm font-semibold">New Signal Detected!</h4>
        <p className="text-xs text-[var(--text-secondary)]">{message}</p>
      </div>
    </div>
  );
}

// Main Page
export default function Dashboard() {
  const [selectedSignal, setSelectedSignal] = useState<Signal | null>(null);
  const [filter, setFilter] = useState('all');
  const [toast, setToast] = useState<string | null>(null);

  // Simulate real-time updates
  useEffect(() => {
    const newSignals = [
      '"Hyperliquid airdrop" spiking +89%',
      '"Pump.fun alternatives" rising +67%',
      '"Ethena USDe" detected +145%',
    ];
    
    let index = 0;
    const interval = setInterval(() => {
      setToast(newSignals[index % newSignals.length]);
      index++;
    }, 12000);

    return () => clearInterval(interval);
  }, []);

  const filteredSignals = filter === 'all' 
    ? mockSignals 
    : mockSignals.filter(s => s.status === filter);

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      
      <main className="flex-1 ml-[260px] p-8">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-[28px] font-bold tracking-tight mb-1">Signal Dashboard</h1>
            <p className="text-sm text-[var(--text-secondary)]">Real-time narrative detection across 47 active sources</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/30 rounded-full text-green-500 text-sm font-mono">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-blink" />
              SCANNING LIVE
            </div>
            <button className="btn btn-secondary">Export</button>
            <button className="btn btn-primary flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Source
            </button>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <StatCard 
            label="Active Signals" 
            value="127" 
            change="+23% vs last week" 
            icon={Zap} 
            color="cyan" 
          />
          <StatCard 
            label="Hot Trends" 
            value="12" 
            change="+4 new today" 
            icon={TrendingUp} 
            color="orange" 
          />
          <StatCard 
            label="Messages Analyzed" 
            value="847K" 
            change="+156K today" 
            icon={MessageSquare} 
            color="green" 
          />
          <StatCard 
            label="Briefs Generated" 
            value="34" 
            change="+8 this week" 
            icon={FileText} 
            color="purple" 
          />
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-[1fr_400px] gap-6">
          {/* Signals Panel */}
          <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden">
            <div className="p-5 border-b border-[var(--border-color)] flex items-center justify-between">
              <div className="flex items-center gap-2 text-base font-semibold">
                <Zap className="w-5 h-5 text-cyan-400" />
                Trending Signals
              </div>
              <div className="flex gap-2">
                {['all', 'hot', 'rising', 'emerging'].map(f => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-3 py-1.5 rounded-md text-xs font-mono transition-all border ${
                      filter === f
                        ? 'border-cyan-400 text-cyan-400 bg-cyan-400/10'
                        : 'border-[var(--border-color)] text-[var(--text-secondary)] hover:border-cyan-400'
                    }`}
                  >
                    {f === 'all' ? 'All' : f === 'hot' ? '🔥 Hot' : f === 'rising' ? '📈 Rising' : '🌱 New'}
                  </button>
                ))}
              </div>
            </div>
            <div className="p-4 max-h-[500px] overflow-y-auto space-y-3">
              {filteredSignals.map(signal => (
                <SignalCard 
                  key={signal.id} 
                  signal={signal}
                  onClick={() => setSelectedSignal(signal)}
                />
              ))}
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Radar */}
            <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden">
              <div className="p-5 border-b border-[var(--border-color)] flex items-center gap-2 text-base font-semibold">
                <svg className="w-5 h-5 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"/>
                  <circle cx="12" cy="12" r="6"/>
                  <circle cx="12" cy="12" r="2"/>
                </svg>
                Signal Radar
              </div>
              <RadarVisualization />
            </div>

            {/* Brief Generator */}
            <div className="bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-2xl overflow-hidden">
              <div className="p-5 border-b border-[var(--border-color)] flex items-center gap-2 text-base font-semibold">
                <FileText className="w-5 h-5 text-cyan-400" />
                Quick Brief
              </div>
              <BriefGenerator signal={selectedSignal || mockSignals[0]} />
            </div>
          </div>
        </div>
      </main>

      {/* Toast */}
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
    </div>
  );
}
