import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/db';
import { SignalStatus } from '@prisma/client';

// GET /api/signals - Fetch signals for current user
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status') as SignalStatus | null;
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    const includeArchived = searchParams.get('archived') === 'true';
    
    const userId = 'demo_user';

    const where: any = {
      userId,
      isArchived: includeArchived ? undefined : false,
    };
    
    if (status) {
      where.status = status;
    }

    const signals = await prisma.signal.findMany({
      where,
      include: {
        sources: {
          include: {
            source: {
              select: { type: true, name: true },
            },
          },
        },
      },
      orderBy: [{ status: 'asc' }, { change24h: 'desc' }],
      take: limit,
      skip: offset,
    });

    const total = await prisma.signal.count({ where });

    const transformedSignals = signals.map(signal => ({
      id: signal.id,
      keyword: signal.keyword,
      status: signal.status.toLowerCase(),
      mentions: signal.mentions,
      change24h: signal.change24h,
      sentiment: Math.round(signal.sentiment * 100),
      influencerSeeds: signal.influencerSeeds,
      sources: signal.sources.map(ss => ss.source.type.toLowerCase()),
      trendData: signal.trendData as number[],
      firstSeen: signal.firstSeen.toISOString(),
      lastSeen: signal.lastSeen.toISOString(),
    }));

    return NextResponse.json({
      signals: transformedSignals,
      pagination: { total, limit, offset, hasMore: offset + signals.length < total },
    });
  } catch (error) {
    return NextResponse.json({
      signals: getMockSignals(),
      pagination: { total: 5, limit: 20, offset: 0, hasMore: false },
      _demo: true,
    });
  }
}

// POST /api/signals
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword, mentions, sentiment, sources, influencerSeeds } = body;

    if (!keyword) {
      return NextResponse.json({ error: 'Keyword is required' }, { status: 400 });
    }

    const userId = 'demo_user';

    const existing = await prisma.signal.findUnique({
      where: { userId_keyword: { userId, keyword } },
    });

    const mentionsPrev = existing?.mentions || 0;
    const change24h = mentionsPrev > 0 
      ? ((mentions - mentionsPrev) / mentionsPrev) * 100 
      : 100;

    let status: SignalStatus = 'NEW';
    if (change24h > 200) status = 'HOT';
    else if (change24h > 100) status = 'RISING';
    else if (change24h > 50) status = 'EMERGING';

    const existingTrend = (existing?.trendData as number[]) || [];
    const newTrend = [...existingTrend.slice(-23), mentions];

    const signal = await prisma.signal.upsert({
      where: { userId_keyword: { userId, keyword } },
      create: {
        userId, keyword, mentions, mentionsPrev24h: 0, change24h,
        sentiment: sentiment || 0.5, influencerSeeds: influencerSeeds || 0,
        status, trendData: newTrend,
      },
      update: {
        mentions, mentionsPrev24h: mentionsPrev, change24h,
        sentiment: sentiment || existing?.sentiment || 0.5,
        influencerSeeds: influencerSeeds || existing?.influencerSeeds || 0,
        status, trendData: newTrend, lastSeen: new Date(),
        peakAt: change24h > (existing?.change24h || 0) ? new Date() : existing?.peakAt,
      },
    });

    return NextResponse.json({
      success: true,
      signal: { id: signal.id, keyword: signal.keyword, status: signal.status.toLowerCase(), mentions: signal.mentions, change24h: signal.change24h },
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update signal' }, { status: 500 });
  }
}

function getMockSignals() {
  return [
    { id: '1', keyword: '$VIRTUAL agents', status: 'hot', mentions: 2847, change24h: 340, sentiment: 78, influencerSeeds: 12, sources: ['discord', 'twitter', 'telegram'], trendData: [20, 25, 30, 35, 28, 45, 55, 70, 85, 100], firstSeen: new Date(Date.now() - 86400000 * 2).toISOString(), lastSeen: new Date().toISOString() },
    { id: '2', keyword: 'Base chain migration', status: 'rising', mentions: 1203, change24h: 127, sentiment: 72, influencerSeeds: 7, sources: ['discord', 'twitter'], trendData: [15, 20, 18, 25, 35, 50, 60, 75, 70, 85], firstSeen: new Date(Date.now() - 86400000 * 3).toISOString(), lastSeen: new Date().toISOString() },
    { id: '3', keyword: 'MCP protocol', status: 'emerging', mentions: 487, change24h: 78, sentiment: 82, influencerSeeds: 3, sources: ['twitter', 'telegram'], trendData: [10, 12, 15, 20, 28, 35, 45, 52, 60, 68], firstSeen: new Date(Date.now() - 86400000).toISOString(), lastSeen: new Date().toISOString() },
    { id: '4', keyword: 'Solana restaking', status: 'rising', mentions: 892, change24h: 95, sentiment: 69, influencerSeeds: 5, sources: ['discord', 'twitter', 'telegram'], trendData: [25, 30, 28, 40, 45, 55, 65, 58, 72, 80], firstSeen: new Date(Date.now() - 86400000 * 4).toISOString(), lastSeen: new Date().toISOString() },
    { id: '5', keyword: 'AI agents trading', status: 'emerging', mentions: 324, change24h: 56, sentiment: 74, influencerSeeds: 2, sources: ['twitter'], trendData: [8, 12, 10, 18, 22, 30, 38, 42, 48, 55], firstSeen: new Date(Date.now() - 86400000).toISOString(), lastSeen: new Date().toISOString() },
  ];
}
