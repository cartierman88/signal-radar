import { NextRequest, NextResponse } from 'next/server';
import { generateBrief, SignalData, BriefTone } from '@/lib/integrations/openai';
import prisma from '@/lib/db';

// POST /api/briefs - Generate a content brief
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { signalId, tone = 'professional' } = body;

    if (!signalId) {
      return NextResponse.json({ error: 'signalId is required' }, { status: 400 });
    }

    const userId = 'demo_user';

    // Try to fetch signal from database
    let signalData: SignalData;
    
    try {
      const signal = await prisma.signal.findUnique({
        where: { id: signalId },
        include: {
          sources: {
            include: { source: true },
          },
        },
      });

      if (!signal) {
        return NextResponse.json({ error: 'Signal not found' }, { status: 404 });
      }

      signalData = {
        keyword: signal.keyword,
        mentions: signal.mentions,
        change24h: signal.change24h,
        sentiment: signal.sentiment * 100,
        sources: signal.sources.map(s => s.source.type.toLowerCase()),
        influencerSeeds: signal.influencerSeeds,
        trendData: signal.trendData as number[],
      };
    } catch (dbError) {
      // Fallback to mock data if DB not available
      signalData = getMockSignalData(signalId);
    }

    // Generate brief using OpenAI
    const brief = await generateBrief(signalData, tone as BriefTone);

    // Save to database
    try {
      await prisma.contentBrief.create({
        data: {
          userId,
          signalId,
          hook: brief.hook,
          keyAngles: brief.keyAngles,
          dataPoints: brief.dataPoints,
          hashtags: brief.suggestedHashtags,
          twitterThread: brief.twitterThread.join('\n\n---\n\n'),
          linkedinPost: brief.linkedinPost,
          newsletter: brief.newsletter,
          tone: tone.toUpperCase() as any,
        },
      });
    } catch (saveError) {
      console.log('[Briefs] Could not save to DB, returning generated brief');
    }

    return NextResponse.json({
      success: true,
      brief: {
        hook: brief.hook,
        keyAngles: brief.keyAngles,
        dataPoints: brief.dataPoints,
        suggestedHashtags: brief.suggestedHashtags,
        platforms: {
          twitter: brief.twitterThread,
          linkedin: brief.linkedinPost,
          newsletter: brief.newsletter,
        },
      },
    });
  } catch (error) {
    console.error('[Briefs API] Error:', error);
    return NextResponse.json(
      { error: 'Failed to generate brief' },
      { status: 500 }
    );
  }
}

// GET /api/briefs - Get user's saved briefs
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    
    const userId = 'demo_user';

    const briefs = await prisma.contentBrief.findMany({
      where: { userId },
      include: {
        signal: {
          select: { keyword: true, status: true },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });

    return NextResponse.json({
      briefs: briefs.map(b => ({
        id: b.id,
        signalKeyword: b.signal?.keyword,
        hook: b.hook,
        keyAngles: b.keyAngles,
        dataPoints: b.dataPoints,
        hashtags: b.hashtags,
        tone: b.tone.toLowerCase(),
        status: b.status.toLowerCase(),
        createdAt: b.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    return NextResponse.json({ briefs: [], _demo: true });
  }
}

function getMockSignalData(signalId: string): SignalData {
  const mockSignals: Record<string, SignalData> = {
    '1': {
      keyword: '$VIRTUAL agents',
      mentions: 2847,
      change24h: 340,
      sentiment: 78,
      sources: ['discord', 'twitter', 'telegram'],
      influencerSeeds: 12,
      trendData: [20, 25, 30, 35, 28, 45, 55, 70, 85, 100],
    },
    '2': {
      keyword: 'Base chain migration',
      mentions: 1203,
      change24h: 127,
      sentiment: 72,
      sources: ['discord', 'twitter'],
      influencerSeeds: 7,
      trendData: [15, 20, 18, 25, 35, 50, 60, 75, 70, 85],
    },
    '3': {
      keyword: 'MCP protocol',
      mentions: 487,
      change24h: 78,
      sentiment: 82,
      sources: ['twitter', 'telegram'],
      influencerSeeds: 3,
      trendData: [10, 12, 15, 20, 28, 35, 45, 52, 60, 68],
    },
  };

  return mockSignals[signalId] || mockSignals['1'];
}
