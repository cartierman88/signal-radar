import { NextRequest, NextResponse } from 'next/server';
import { Source } from '@/types';

// In production, this would be stored in a database
let sources: Source[] = [
  {
    id: '1',
    type: 'discord',
    name: 'DeFi Alpha',
    channelId: '123456789',
    isActive: true,
    lastSync: new Date(),
    messageCount: 45230
  },
  {
    id: '2',
    type: 'twitter',
    name: 'Crypto Twitter Lists',
    url: 'https://twitter.com/i/lists/crypto-alpha',
    isActive: true,
    lastSync: new Date(),
    messageCount: 128450
  },
  {
    id: '3',
    type: 'telegram',
    name: 'Solana Trading',
    channelId: '@soltrading',
    isActive: true,
    lastSync: new Date(),
    messageCount: 67890
  },
  {
    id: '4',
    type: 'discord',
    name: 'Base Builders',
    channelId: '987654321',
    isActive: false,
    lastSync: new Date(Date.now() - 24 * 60 * 60 * 1000),
    messageCount: 23100
  },
  {
    id: '5',
    type: 'twitter',
    name: 'AI/ML Researchers',
    url: 'https://twitter.com/i/lists/ai-researchers',
    isActive: true,
    lastSync: new Date(),
    messageCount: 34500
  }
];

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const type = searchParams.get('type');
  const activeOnly = searchParams.get('active') === 'true';

  let filteredSources = [...sources];

  if (type) {
    filteredSources = filteredSources.filter(s => s.type === type);
  }

  if (activeOnly) {
    filteredSources = filteredSources.filter(s => s.isActive);
  }

  return NextResponse.json({
    sources: filteredSources,
    totalCount: filteredSources.length,
    stats: {
      discord: sources.filter(s => s.type === 'discord').length,
      twitter: sources.filter(s => s.type === 'twitter').length,
      telegram: sources.filter(s => s.type === 'telegram').length,
      activeCount: sources.filter(s => s.isActive).length
    }
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, name, channelId, url } = body;

    if (!type || !name) {
      return NextResponse.json(
        { error: 'Type and name are required' },
        { status: 400 }
      );
    }

    const newSource: Source = {
      id: `src_${Date.now()}`,
      type,
      name,
      channelId,
      url,
      isActive: true,
      lastSync: new Date(),
      messageCount: 0
    };

    sources.push(newSource);

    return NextResponse.json({
      success: true,
      source: newSource
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to add source' },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, isActive } = body;

    const sourceIndex = sources.findIndex(s => s.id === id);
    
    if (sourceIndex === -1) {
      return NextResponse.json(
        { error: 'Source not found' },
        { status: 404 }
      );
    }

    sources[sourceIndex] = {
      ...sources[sourceIndex],
      isActive: isActive !== undefined ? isActive : sources[sourceIndex].isActive,
      lastSync: new Date()
    };

    return NextResponse.json({
      success: true,
      source: sources[sourceIndex]
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update source' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json();
    const { id } = body;

    const sourceIndex = sources.findIndex(s => s.id === id);
    
    if (sourceIndex === -1) {
      return NextResponse.json(
        { error: 'Source not found' },
        { status: 404 }
      );
    }

    const deletedSource = sources.splice(sourceIndex, 1)[0];

    return NextResponse.json({
      success: true,
      deletedSource
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete source' },
      { status: 500 }
    );
  }
}
