import { NextRequest, NextResponse } from 'next/server';
import { getTelegramClient } from '@/lib/integrations/telegram';

export async function POST(
  request: NextRequest,
  { params }: { params: { secret: string } }
) {
  // Verify webhook secret
  const expectedSecret = process.env.TELEGRAM_WEBHOOK_SECRET;
  
  if (params.secret !== expectedSecret) {
    return NextResponse.json({ error: 'Invalid secret' }, { status: 403 });
  }

  try {
    const update = await request.json();
    
    // Get Telegram client and handle update
    const telegram = getTelegramClient();
    telegram.handleUpdate(update);

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('[Telegram Webhook] Error:', error);
    return NextResponse.json(
      { error: 'Failed to process update' },
      { status: 500 }
    );
  }
}

// Telegram sends GET request to verify webhook
export async function GET() {
  return NextResponse.json({ status: 'Telegram webhook active' });
}
