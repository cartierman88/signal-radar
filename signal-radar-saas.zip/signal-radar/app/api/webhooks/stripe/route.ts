import { NextRequest, NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { handleWebhookEvent } from '@/lib/integrations/stripe';
import prisma from '@/lib/db';

export async function POST(request: NextRequest) {
  const body = await request.text();
  const signature = headers().get('stripe-signature');

  if (!signature) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 });
  }

  try {
    const result = await handleWebhookEvent(body, signature);

    if (!result) {
      // Event type not handled
      return NextResponse.json({ received: true });
    }

    switch (result.event) {
      case 'checkout.completed': {
        const { userId, customerId, subscriptionId, planType } = result.data;
        
        // Update user with subscription info
        await prisma.user.update({
          where: { id: userId },
          data: {
            stripeCustomerId: customerId,
            stripeSubscriptionId: subscriptionId,
            plan: planType as any,
          },
        });

        console.log(`[Stripe] User ${userId} subscribed to ${planType}`);
        break;
      }

      case 'subscription.updated': {
        const { subscriptionId, currentPeriodEnd, cancelAtPeriodEnd, priceId } = result.data;
        
        // Find user by subscription ID and update
        const user = await prisma.user.findFirst({
          where: { stripeSubscriptionId: subscriptionId },
        });

        if (user) {
          await prisma.user.update({
            where: { id: user.id },
            data: {
              stripeCurrentPeriodEnd: currentPeriodEnd,
              stripePriceId: priceId,
            },
          });
        }

        console.log(`[Stripe] Subscription ${subscriptionId} updated`);
        break;
      }

      case 'subscription.deleted': {
        const { subscriptionId } = result.data;
        
        // Find user and downgrade to free
        const user = await prisma.user.findFirst({
          where: { stripeSubscriptionId: subscriptionId },
        });

        if (user) {
          await prisma.user.update({
            where: { id: user.id },
            data: {
              plan: 'FREE',
              stripeSubscriptionId: null,
              stripePriceId: null,
              stripeCurrentPeriodEnd: null,
            },
          });
        }

        console.log(`[Stripe] Subscription ${subscriptionId} deleted, user downgraded`);
        break;
      }

      case 'payment.failed': {
        const { customerId } = result.data;
        
        // TODO: Send email notification about failed payment
        console.log(`[Stripe] Payment failed for customer ${customerId}`);
        break;
      }

      case 'payment.succeeded': {
        const { customerId, amount } = result.data;
        console.log(`[Stripe] Payment of $${amount / 100} succeeded for ${customerId}`);
        break;
      }
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('[Stripe Webhook] Error:', error);
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 400 }
    );
  }
}

// Disable body parsing for raw body access
export const config = {
  api: {
    bodyParser: false,
  },
};
