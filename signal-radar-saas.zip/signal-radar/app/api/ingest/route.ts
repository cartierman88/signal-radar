import { NextRequest, NextResponse } from 'next/server';
import { IngestPayload, RawMessage } from '@/types';

// In production, this would:
// 1. Validate the webhook signature
// 2. Queue messages for processing
// 3. Store in database
// 4. Trigger signal detection pipeline

interface ProcessingResult {
  messagesProcessed: number;
  keywordsDetected: string[];
  spikesDetected: number;
}

// Simple keyword extraction for demo
function extractKeywords(content: string): string[] {
  const keywords: string[] = [];
  
  // Token tickers
  const tickers = content.match(/\$[A-Z]{2,10}/g) || [];
  keywords.push(...tickers);
  
  // Common crypto terms
  const terms = [
    'airdrop', 'launch', 'migration', 'restaking', 'yield',
    'AI agent', 'autonomous', 'protocol', 'layer 2', 'L2',
    'pump', 'moon', 'alpha', 'degen'
  ];
  
  const lowerContent = content.toLowerCase();
  for (const term of terms) {
    if (lowerContent.includes(term.toLowerCase())) {
      keywords.push(term);
    }
  }
  
  return [...new Set(keywords)];
}

async function processMessages(messages: RawMessage[]): Promise<ProcessingResult> {
  const allKeywords: string[] = [];
  
  for (const msg of messages) {
    const keywords = extractKeywords(msg.content);
    allKeywords.push(...keywords);
  }
  
  const keywordCounts = new Map<string, number>();
  for (const kw of allKeywords) {
    keywordCounts.set(kw, (keywordCounts.get(kw) || 0) + 1);
  }
  
  // Detect spikes (keywords appearing more than threshold)
  const spikeThreshold = Math.max(5, messages.length * 0.1);
  const spikes = Array.from(keywordCounts.entries())
    .filter(([_, count]) => count >= spikeThreshold);
  
  return {
    messagesProcessed: messages.length,
    keywordsDetected: [...new Set(allKeywords)],
    spikesDetected: spikes.length
  };
}

export async function POST(request: NextRequest) {
  try {
    // Verify webhook signature (implement in production)
    const signature = request.headers.get('x-webhook-signature');
    // if (!verifySignature(signature, body)) { return 401 }

    const body: IngestPayload = await request.json();
    const { source, channelId, messages } = body;

    if (!source || !messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Invalid payload: source and messages array required' },
        { status: 400 }
      );
    }

    // Validate message format
    const validMessages = messages.filter(msg => 
      msg.id && msg.content && msg.author && msg.timestamp
    );

    if (validMessages.length === 0) {
      return NextResponse.json(
        { error: 'No valid messages in payload' },
        { status: 400 }
      );
    }

    // Process messages
    const result = await processMessages(validMessages);

    // Log for monitoring (replace with proper logging in production)
    console.log(`[INGEST] ${source}/${channelId}: ${result.messagesProcessed} messages, ${result.spikesDetected} spikes`);

    return NextResponse.json({
      success: true,
      source,
      channelId,
      result,
      processedAt: new Date().toISOString()
    });

  } catch (error) {
    console.error('Ingest error:', error);
    return NextResponse.json(
      { error: 'Failed to process ingest payload' },
      { status: 500 }
    );
  }
}

// Health check endpoint
export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    endpoint: '/api/ingest',
    acceptedSources: ['discord', 'twitter', 'telegram'],
    payloadFormat: {
      source: 'string (discord|twitter|telegram)',
      channelId: 'string',
      messages: [{
        id: 'string',
        content: 'string',
        author: 'string',
        timestamp: 'ISO string',
        engagement: 'number (optional)'
      }]
    }
  });
}
