import { NextRequest, NextResponse } from 'next/server';
import { createCheckoutSession, PLANS } from '@/lib/integrations/stripe';
// import { getServerSession } from 'next-auth';
// import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    // In production, get session from NextAuth
    // const session = await getServerSession(authOptions);
    // if (!session?.user) {
    //   return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    // }

    const body = await request.json();
    const { planType } = body;

    if (!planType || !['STARTER', 'PRO', 'ENTERPRISE'].includes(planType)) {
      return NextResponse.json(
        { error: 'Invalid plan type' },
        { status: 400 }
      );
    }

    // Mock user for development - replace with session.user in production
    const user = {
      id: 'user_demo_123',
      email: 'demo@example.com',
    };

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

    const checkoutUrl = await createCheckoutSession({
      userId: user.id,
      userEmail: user.email,
      planType: planType as 'STARTER' | 'PRO' | 'ENTERPRISE',
      successUrl: `${appUrl}/dashboard?checkout=success`,
      cancelUrl: `${appUrl}/pricing?checkout=cancelled`,
    });

    return NextResponse.json({ url: checkoutUrl });
  } catch (error) {
    console.error('[Checkout] Error:', error);
    return NextResponse.json(
      { error: 'Failed to create checkout session' },
      { status: 500 }
    );
  }
}

export async function GET() {
  // Return available plans
  return NextResponse.json({
    plans: Object.entries(PLANS).map(([key, plan]) => ({
      id: key,
      name: plan.name,
      price: plan.price,
      features: plan.features,
    })),
  });
}
