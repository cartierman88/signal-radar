/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          primary: '#0a0a0f',
          secondary: '#12121a',
          tertiary: '#1a1a25',
        },
        text: {
          primary: '#e4e4e7',
          secondary: '#71717a',
          muted: '#52525b',
        },
        accent: {
          cyan: '#06b6d4',
          'cyan-dim': 'rgba(6, 182, 212, 0.15)',
          green: '#22c55e',
          'green-dim': 'rgba(34, 197, 94, 0.15)',
          orange: '#f97316',
          'orange-dim': 'rgba(249, 115, 22, 0.15)',
          red: '#ef4444',
          'red-dim': 'rgba(239, 68, 68, 0.15)',
          purple: '#a855f7',
          'purple-dim': 'rgba(168, 85, 247, 0.15)',
        },
      },
      fontFamily: {
        sans: ['Space Grotesk', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'blink': 'blink 1.5s ease-in-out infinite',
        'sweep': 'sweep 4s linear infinite',
        'blip': 'blip-pulse 2s ease-in-out infinite',
        'slide-in': 'slideIn 0.3s ease',
        'fade-in': 'fadeIn 0.3s ease',
        'shimmer': 'shimmer 1.5s infinite',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 30px rgba(6, 182, 212, 0.3)' },
          '50%': { boxShadow: '0 0 40px rgba(168, 85, 247, 0.4)' },
        },
        'blink': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.3' },
        },
        'sweep': {
          from: { transform: 'rotate(0deg)' },
          to: { transform: 'rotate(360deg)' },
        },
        'blip-pulse': {
          '0%, 100%': { opacity: '1', transform: 'translate(-50%, -50%) scale(1)' },
          '50%': { opacity: '0.7', transform: 'translate(-50%, -50%) scale(1.2)' },
        },
        'slideIn': {
          from: { transform: 'translateX(100%)', opacity: '0' },
          to: { transform: 'translateX(0)', opacity: '1' },
        },
        'fadeIn': {
          from: { opacity: '0', transform: 'translateY(10px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'grid-pattern': 'linear-gradient(rgba(6, 182, 212, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.03) 1px, transparent 1px)',
      },
    },
  },
  plugins: [],
}
