# Signal Radar 🎯

**Catch crypto trends 48 hours before mainstream.**

Signal Radar monitors Discord, X (Twitter), and Telegram to detect rising crypto narratives before they hit your timeline. Get AI-powered briefs to publish first and own the conversation.

![Signal Radar Dashboard](https://via.placeholder.com/1200x600/0a0a0f/06b6d4?text=Signal+Radar+Dashboard)

## 🚀 Features

- **Multi-Platform Monitoring** - Discord servers, Twitter/X lists, Telegram groups
- **Real-Time Signal Detection** - Keyword spikes, sentiment shifts, influencer seeds
- **AI Brief Generator** - OpenAI-powered content briefs for instant publishing
- **Smart Alerts** - Email, Slack, Discord, Telegram notifications
- **Cyberpunk Dashboard** - Real-time radar visualization with trend tracking
- **Stripe Subscriptions** - Tiered pricing ($29/$99/$299/mo)

## 📦 Tech Stack

- **Frontend:** Next.js 14, React 18, Tailwind CSS, Framer Motion
- **Backend:** Next.js API Routes, Prisma ORM
- **Database:** PostgreSQL
- **Queue:** Redis + BullMQ
- **AI:** OpenAI GPT-4
- **Payments:** Stripe
- **Auth:** NextAuth.js

---

# 🛠️ LAUNCH GUIDE

## Option 1: Quick Demo (No Backend)

For a quick demo without any backend, just open the standalone HTML file:

```bash
open index.html
```

This shows the full UI with mock data.

---

## Option 2: Full Production Deployment

### Prerequisites

- Node.js 18+ 
- PostgreSQL database
- Redis instance
- API keys for: OpenAI, Stripe, Discord, Twitter, Telegram

### Step 1: Clone & Install

```bash
# Clone the repo
git clone https://github.com/yourusername/signal-radar.git
cd signal-radar

# Install dependencies
npm install
```

### Step 2: Environment Setup

```bash
# Copy example env
cp .env.example .env.local

# Edit with your values
nano .env.local
```

**Required environment variables:**

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/signal_radar"

# Redis
REDIS_URL="redis://localhost:6379"

# Auth
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=generate-with-openssl-rand-base64-32

# OpenAI (for AI briefs)
OPENAI_API_KEY=sk-xxx

# Stripe (for payments)
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_xxx
STRIPE_STARTER_PRICE_ID=price_xxx
STRIPE_PRO_PRICE_ID=price_xxx
STRIPE_ENTERPRISE_PRICE_ID=price_xxx
```

### Step 3: Database Setup

```bash
# Generate Prisma client
npx prisma generate

# Push schema to database
npx prisma db push

# (Optional) Open database GUI
npx prisma studio
```

### Step 4: Run Locally

```bash
# Development mode
npm run dev

# Open http://localhost:3000
```

### Step 5: Deploy to Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables in Vercel dashboard
# Link PostgreSQL (use Vercel Postgres or external)
# Link Redis (use Upstash or external)
```

**Vercel Dashboard Setup:**
1. Go to vercel.com/dashboard
2. Import your GitHub repo
3. Add all environment variables from `.env.local`
4. Deploy!

### Step 6: Configure Stripe Webhooks

1. Go to Stripe Dashboard → Developers → Webhooks
2. Add endpoint: `https://yourdomain.com/api/webhooks/stripe`
3. Select events:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
   - `invoice.payment_succeeded`
4. Copy webhook secret to `STRIPE_WEBHOOK_SECRET`

### Step 7: Create Stripe Products

```bash
# In Stripe Dashboard, create 3 products:

# Starter - $29/mo
# Pro - $99/mo  
# Enterprise - $299/mo

# Copy the price IDs to your .env
```

### Step 8: Set Up Platform Integrations

#### Discord Bot
1. Go to discord.com/developers/applications
2. Create new application
3. Go to Bot → Create Bot
4. Copy token to `DISCORD_BOT_TOKEN`
5. Enable MESSAGE CONTENT INTENT
6. Invite bot to servers with this URL:
   ```
   https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=68608&scope=bot
   ```

#### Twitter/X API
1. Go to developer.twitter.com
2. Create project with Elevated access
3. Generate Bearer Token
4. Copy to `TWITTER_BEARER_TOKEN`

#### Telegram Bot
1. Message @BotFather on Telegram
2. Create new bot with /newbot
3. Copy token to `TELEGRAM_BOT_TOKEN`
4. Set webhook:
   ```
   https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://yourdomain.com/api/webhooks/telegram/<SECRET>
   ```

### Step 9: Start Background Workers (Production)

For production, you need to run the job workers separately:

```bash
# Create worker script: worker.js
node -e "
const { startSourceMonitoring, scheduleSignalCalculations } = require('./lib/jobs/processor');

async function main() {
  console.log('Starting Signal Radar workers...');
  await startSourceMonitoring('*');
  await scheduleSignalCalculations();
  console.log('Workers running!');
}

main();
"
```

**For Vercel:** Use Vercel Cron Jobs or a separate worker on Railway/Render.

---

## 📁 Project Structure

```
signal-radar/
├── app/
│   ├── (auth)/           # Login/Signup pages
│   ├── (dashboard)/      # Main dashboard
│   ├── (marketing)/      # Landing page
│   └── api/              # API routes
│       ├── auth/         # NextAuth
│       ├── briefs/       # Content briefs
│       ├── checkout/     # Stripe checkout
│       ├── signals/      # Signal CRUD
│       ├── sources/      # Source management
│       └── webhooks/     # Stripe/Telegram webhooks
├── lib/
│   ├── integrations/     # Discord, Twitter, Telegram, Stripe, OpenAI
│   ├── jobs/             # BullMQ workers
│   ├── auth.ts           # NextAuth config
│   ├── db.ts             # Prisma client
│   └── signal-engine.ts  # Signal detection logic
├── prisma/
│   └── schema.prisma     # Database schema
├── types/
│   └── index.ts          # TypeScript types
└── index.html            # Standalone demo
```

---

## 🎨 Customization

### Change Colors
Edit `tailwind.config.js`:
```js
colors: {
  accent: {
    cyan: '#06b6d4',    // Primary accent
    purple: '#a855f7',  // Secondary accent
  }
}
```

### Change Pricing
Edit `lib/integrations/stripe.ts`:
```ts
export const PLANS = {
  STARTER: { price: 29, ... },
  PRO: { price: 99, ... },
  ENTERPRISE: { price: 299, ... },
}
```

---

## 🔧 API Reference

### Signals
```bash
# Get signals
GET /api/signals?status=hot&limit=20

# Create/update signal
POST /api/signals
{ "keyword": "AI agents", "mentions": 500 }
```

### Briefs
```bash
# Generate brief
POST /api/briefs
{ "signalId": "123", "tone": "urgent" }
```

### Webhooks
```bash
# Ingest external messages
POST /api/ingest
{ "source": "discord", "channelId": "xxx", "messages": [...] }
```

---

## 🚨 Troubleshooting

### Database Connection Error
```bash
# Check DATABASE_URL format
postgresql://USER:PASSWORD@HOST:PORT/DATABASE

# Test connection
npx prisma db pull
```

### Stripe Webhook Failing
```bash
# Test locally with Stripe CLI
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

### Redis Connection Error
```bash
# Test Redis
redis-cli ping
# Should return PONG
```

---

## 📈 Scaling

For high-volume production:

1. **Database:** Use connection pooling (PgBouncer)
2. **Redis:** Use Redis Cluster or Upstash
3. **Workers:** Deploy on Railway/Render with auto-scaling
4. **CDN:** Enable Vercel Edge caching
5. **Monitoring:** Add Sentry + LogRocket

---

## 🤝 Support

- Documentation: https://docs.signalradar.io
- Discord: https://discord.gg/signalradar
- Twitter: https://twitter.com/signalradar

---

## 📄 License

MIT License - feel free to use for your own SaaS!

---

Built with ❤️ for the alpha hunters.
