#!/bin/bash

# Signal Radar - Quick Start Script
# ===================================

echo "🎯 Signal Radar - Quick Start"
echo "=============================="
echo ""

# Check if Docker is available
if command -v docker &> /dev/null; then
    echo "✅ Docker found"
    USE_DOCKER=true
else
    echo "⚠️  Docker not found - will use local setup"
    USE_DOCKER=false
fi

# Check if Node is available
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo "✅ Node.js found: $NODE_VERSION"
else
    echo "❌ Node.js not found. Please install Node.js 18+"
    exit 1
fi

echo ""
echo "Choose setup option:"
echo "1) Docker (PostgreSQL + Redis in containers)"
echo "2) Local only (you provide PostgreSQL + Redis)"
echo "3) Demo mode (mock data, no database)"
echo ""
read -p "Enter choice [1-3]: " choice

case $choice in
    1)
        echo ""
        echo "🐳 Starting Docker containers..."
        docker-compose up -d postgres redis
        
        echo "⏳ Waiting for databases..."
        sleep 5
        
        # Set local env
        export DATABASE_URL="postgresql://signal_radar:signal_radar_password@localhost:5432/signal_radar"
        export REDIS_URL="redis://localhost:6379"
        ;;
    2)
        echo ""
        echo "📝 Please set your environment variables in .env.local"
        if [ ! -f .env.local ]; then
            cp .env.example .env.local
            echo "Created .env.local from template"
        fi
        echo "Edit .env.local with your database and Redis URLs"
        read -p "Press Enter when ready..."
        ;;
    3)
        echo ""
        echo "🎮 Starting in demo mode..."
        export DEMO_MODE=true
        ;;
esac

echo ""
echo "📦 Installing dependencies..."
npm install

if [ "$DEMO_MODE" != "true" ]; then
    echo ""
    echo "🗄️  Setting up database..."
    npx prisma generate
    npx prisma db push
fi

echo ""
echo "🚀 Starting Signal Radar..."
echo ""
echo "================================================"
echo "  Open http://localhost:3000 in your browser"
echo "================================================"
echo ""

npm run dev
