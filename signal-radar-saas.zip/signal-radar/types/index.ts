// Core signal types
export interface Signal {
  id: string;
  keyword: string;
  status: 'hot' | 'rising' | 'emerging' | 'new';
  mentions: number;
  change24h: number; // percentage
  sentiment: number; // 0-100
  sources: Source[];
  firstSeen: Date;
  lastSeen: Date;
  samplePosts: SamplePost[];
  influencerSeeds: number;
  trendData: TrendDataPoint[];
}

export interface TrendDataPoint {
  timestamp: Date;
  mentions: number;
  sentiment: number;
}

export interface Source {
  id: string;
  type: 'discord' | 'twitter' | 'telegram';
  name: string;
  url?: string;
  channelId?: string;
  isActive: boolean;
  lastSync: Date;
  messageCount: number;
}

export interface SamplePost {
  id: string;
  source: 'discord' | 'twitter' | 'telegram';
  author: string;
  content: string;
  timestamp: Date;
  engagement: number;
  isInfluencer: boolean;
}

// Content brief types
export interface ContentBrief {
  id: string;
  signalId: string;
  keyword: string;
  generatedAt: Date;
  hook: string;
  keyAngles: string[];
  dataPoints: DataPoint[];
  suggestedHashtags: string[];
  toneGuidance: string;
  platforms: Platform[];
  scheduledFor?: Date;
  status: 'draft' | 'scheduled' | 'published';
}

export interface DataPoint {
  label: string;
  value: string;
  source?: string;
}

export interface Platform {
  name: 'twitter' | 'linkedin' | 'newsletter' | 'discord';
  adaptedContent: string;
  characterCount: number;
}

// Alert configuration
export interface AlertRule {
  id: string;
  name: string;
  type: 'keyword_spike' | 'sentiment_shift' | 'influencer_seed' | 'recurring_question';
  threshold: number;
  timeWindow: number; // hours
  channels: ('email' | 'slack' | 'discord' | 'telegram')[];
  isActive: boolean;
}

// API response types
export interface SignalsResponse {
  signals: Signal[];
  totalCount: number;
  lastUpdated: Date;
}

export interface BriefGenerateRequest {
  signalId: string;
  tone?: 'professional' | 'casual' | 'urgent' | 'educational';
  platforms?: ('twitter' | 'linkedin' | 'newsletter')[];
}

export interface IngestPayload {
  source: 'discord' | 'twitter' | 'telegram';
  channelId: string;
  messages: RawMessage[];
}

export interface RawMessage {
  id: string;
  content: string;
  author: string;
  timestamp: string;
  engagement?: number;
}

// Store state
export interface AppState {
  signals: Signal[];
  sources: Source[];
  alerts: AlertRule[];
  briefs: ContentBrief[];
  isScanning: boolean;
  lastSyncTime: Date | null;
  stats: DashboardStats;
}

export interface DashboardStats {
  activeSignals: number;
  hotTrends: number;
  messagesAnalyzed: number;
  briefsGenerated: number;
  sourcesActive: number;
}
